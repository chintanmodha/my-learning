import azureDevOps as ado
import datetime as dt

projectname = 'MTS'
reponame = 'MTS'

# get start date
buildList = ado.getBuildList(projectname,'9272','succeeded')
# print(buildList)
# print(type(buildList))
my_dict = buildList
latestBuild = my_dict['value'][0]
print(latestBuild['buildNumber'], latestBuild['startTime'], latestBuild['finishTime'])
timeStamp = latestBuild['finishTime']

# get repoId
repoId = ado.getRepoId(projectname,reponame)
print(f'RepoName: {reponame} - RepoId: {repoId}')

commits = ado.getCommitList(projectname,reponame,timeStamp)
#print(commits)
files = ado.getCommittedFiles(projectname,reponame,timeStamp)
for file in files:
    print(file)


#
# import json
# import requests
# import base64
#
# access_token = ''
# authorization = str(base64.b64encode(bytes(':'+access_token, 'ascii')), 'ascii')
# print(authorization)
# url = "https://dev.azure.com/spglobal/MTS/_apis/build/builds?definitions=9272&resultFilter=succeeded&queryorder=finishTimeDescending&api-version=6.0"
# queryparam_dict = {}
# my_headers = {'Authorization' : 'Basic '+authorization,'Accept': 'application/json'}
# response = requests.get(url, headers=my_headers, verify=False)
#
# print(response.status_code)
# print(response.text)
#
#
