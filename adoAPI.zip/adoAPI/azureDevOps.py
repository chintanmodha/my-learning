import requests
import base64
from collections import Counter
import json


def getUnique(list):
    # initialize a null list
    unique_list = []
    for x in list:
        if x not in unique_list:
            unique_list.append(x)
    return unique_list
def getHeader():
    access_token = 'qww7ubxvaseltixdrijwocooucwelymuysemeamru3nne67edhra'
    authorization = str(base64.b64encode(bytes(':' + access_token, 'ascii')), 'ascii')
    my_headers = {'Authorization': 'Basic ' + authorization, 'Accept': 'application/json'}
    return my_headers
def getBuildList(project,buildDefinitionId,buildStatus,debug=False):
    baseURL = "https://dev.azure.com/spglobal/projectName/_apis/build/builds?definitions=definitionID&resultFilter=resultStatus&queryorder=finishTimeDescending&api-version=6.0"
    requestURL = baseURL.replace('projectName', project)
    requestURL = requestURL.replace('definitionID',buildDefinitionId)
    requestURL = requestURL.replace('resultStatus',buildStatus)
    header = getHeader()
    if debug:
        print(f'Header: {header}, RequestURL: {requestURL}')
    response = requests.get(requestURL,headers=header,verify=False)
    return response.json()
def getRepoId(project,repoName,debug=False):
    baseURL = "https://dev.azure.com/spglobal/projectName/_apis/git/repositories?api-version=6.0"
    requestURL = baseURL.replace('projectName', project)
    header = getHeader()
    repoListResponse = requests.get(requestURL,headers=header,verify=False)
    repoList = repoListResponse.json()['value']
    if debug:
        print(f'Header: {header}, RequestURL: {requestURL}')
        print(repoList)
        print(type(repoList))
    focus_repo_dict = list(filter(lambda d: d['name'] == repoName, repoList))[0]
    repoId = focus_repo_dict['id']
    return repoId
def getCommitList(project,repoName,timeStamp,debug=False):
    repoId = getRepoId(project, repoName)
    baseURL = "https://dev.azure.com/spglobal/projectName/_apis/git/repositories/repoId/commits?searchCriteria.fromDate=timeStamp&api-version=6.0"
    requestURL = baseURL.replace('projectName', project)
    requestURL = requestURL.replace('repoId', repoId)
    requestURL = requestURL.replace('timeStamp', timeStamp)
    header = getHeader()
    commitListResponse = requests.get(requestURL,headers=header,verify=False)
    commitList = commitListResponse.json()['value']
    if debug:
        print(f'Header: {header}, RequestURL: {requestURL}')
        print(commitList)
        print(type(commitList))
    return commitList

def getCommittedFiles(project,repoName,timeStamp,debug=False):
    repoId = getRepoId(project, repoName)
    commits = getCommitList(project,repoName,timeStamp)
    baseURL = "https://dev.azure.com/spglobal/projectName/_apis/git/repositories/repoId/commits/commitId/changes?api-version=6.0"
    requestURL = baseURL.replace('projectName', project)
    requestURL = requestURL.replace('repoId', repoId)
    file_list = []
    for commit in commits:
        commitId = commit['commitId']
        requestURL = requestURL.replace('commitId', commitId)
        header = getHeader()
        changeListResponse = requests.get(requestURL,headers=header,verify=False)
        changeList = changeListResponse.json()['changes']
        if debug:
            print(changeList)
            print(type(changeList))
        for change in changeList:
            if change['item']['gitObjectType'] == 'blob':
                file_list.append(change['item']['path'])
    final_file_list = getUnique(file_list)
    return final_file_list

def getProjectList():
    baseURL = "https://dev.azure.com/spglobal/_apis/projects?api-version=6.0"
    requestURL = baseURL
    header = getHeader()
    projectListResponse = requests.get(requestURL, headers=header, verify=False)
    projectList = projectListResponse.json()['value']
    for project in projectList:
        projectId = project['id']
        projectName = project['name']
        print(f'ProjectId: {projectId}, ProjectName: {projectName}')
