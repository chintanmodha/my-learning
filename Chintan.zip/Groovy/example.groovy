def yamlFile = new File("C:\Chintan\Groovy\longfile.yml")

yamlFile.withReader { reader ->
    // Use parse method of YamlSlurper.
    def yaml = new YamlSlurper().parse(reader)
     
    assert yaml.sample
    assert yaml.Groovy == 'Rocks!'
}