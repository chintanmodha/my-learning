﻿
function gettaskgrouplist ([string] $projectname,[string] $pat,[string] $baseurl="https://spglobal.visualstudio.com", [string] $taskIdFilter)
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$tglist = (Invoke-RestMethod ` -Uri "$baseurl/$projectname/_apis/distributedtask/taskgroups?api-version=6.0-preview.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=6.0-preview.1" } ` -Method Get ` -ContentType "application/json" ).value  

return $tglist
}
clear
$detail = 1
$baseurl="https://spglobal.visualstudio.com"
$projectname = 'contentsystems'
$taskID = "e213ff0f-5d5c-4791-802d-52ea3e7be1f1"
#$projectid = '0d845a76-0046-4253-84c4-ccc77a3ea325'
$pat = 'dvclshmpwhbkoeqbcecpawbsmuwmddk4oaay26uivologeybdfkq'
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$tgs = gettaskgrouplist -projectname $projectname -pat $pat -taskIdFilter $taskID

$uri = "$baseurl/$projectname/_apis/distributedtask/taskgroups?taskIdFilter=$taskID&api-version=6.0-preview.1"
#$uri = "https://dev.azure.com/spglobal/contentsystems/_apis/distributedtask/taskgroups/0ff33667-cf78-4903-8c9c-5bf1af77ea06"
#$tgs = (Invoke-RestMethod -Uri $uri1 -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=6.0-preview.1" } ` -Method Get ` -ContentType "application/json" ).value
foreach($tg in $tgs){
  foreach ($task in $tg.tasks){
   if($task.task.id.ToString() -eq $taskID)
   {
     
     if($task.inputs.script.tostring() -match "sourceanalyzer.exe")
     {
         write-host "----Group: "$tg.name" Task: "$task.displayName"---"
         if($detail -eq 1 )
         {
           write-host $task.inputs.script.tostring()
         }
     }
    }
}

}
<#
if ($tg.name.ToString() -match "AuditReporter")
    {
        write-host "Found------------"
        write-host $tg.name
    }
    else
    {

write-host "Not Found------------"
write-host $tg.name
#>
}

cd..