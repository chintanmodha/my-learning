﻿$projectname = 'CSD-Services'
$projectid = '73f78e08-e7e3-4fa3-a40c-6cf3c709a7da'
$pat = 'jokosizlshbve6spahju7ryu3gemvqgj7xcjmbyvprkvjaarjasq' 

$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$filteredbuilds = (Invoke-RestMethod ` -Uri "https://spglobal.visualstudio.com/$projectname/_apis/build/definitions?api-version=5.1&taskIdFilter=71a9a2d3-a98a-4caa-96ab-affca411ecda" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
$filteredbuildids = $filteredbuilds | select id 
$buildnumber = 2072

write-host "------------------https://spglobal.visualstudio.com/$projectname/_apis/build/definitions/$buildnumber-----------------"
$defresponse = (Invoke-WebRequest ` -Uri "https://spglobal.visualstudio.com/$projectid/_apis/build/Definitions/$buildnumber" -ContentType "application/json" -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" }).Content

 

[void][System.Reflection.Assembly]::LoadFile("$pwd\Newtonsoft.Json.dll")
$buildDefinition = [Newtonsoft.Json.JsonConvert]::DeserializeObject($defresponse)
write-host "##############Original Definition########################"
$buildDefinition.ToString()
#write-host "######################################"
#$buildDefinition.ToString()
#$buildDefinition = [Newtonsoft.Json.JsonConvert]::SerializeObject($buildDefinition)
#$buildDefinition.ToString()
$version = [Newtonsoft.Json.JsonConvert]::SerializeObject("version")
$steps = $buildDefinition.process.phases.steps
foreach($step in $steps)
{
if('71a9a2d3-a98a-4caa-96ab-affca411ecda' -eq $step.task.id.tostring())
{
$step.tostring()
$step.task.id = "c6c4c611-aa2e-4a33-b606-5eaba2196824"
$step.inputs.add("msbuildLocationMethod",$version)
$step.inputs.add("msbuildVersion",$step.inputs.vsVersion)
$step.inputs.add("msbuildArguments",$step.inputs.msbuildArgs)
$step.inputs.Remove("vsVersion")
$step.inputs.Remove("msbuildArgs")
$step.tostring()
}
}

 

$buildDefinitionUpdated = [Newtonsoft.Json.JsonConvert]::SerializeObject($buildDefinition)

 

$postData = [System.Text.Encoding]::UTF8.GetBytes($buildDefinitionUpdated)
write-host "###############After Update#######################"
$postData.ToString()
# The TFS2015 REST endpoint requires an api-version header, otherwise it refuses to work properly.
$headers = @{ "Authorization" = "Basic $auth";"Accept" = "api-version=5.1" }
$response = Invoke-WebRequest -Uri https://spglobal.visualstudio.com/$projectname/_apis/build/definitions/$buildnumber -Headers $headers `
              -Method Put -Body $postData -ContentType "application/json"
$response.StatusDescription
#$response.Content.ToString()

