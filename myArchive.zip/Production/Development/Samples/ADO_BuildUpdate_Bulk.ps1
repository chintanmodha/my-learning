﻿
$projectname = 'csd-datapipelines'
$projectid = '964f86f4-77e9-414c-ab69-3d9adb08a6bc'
$pat = 'jokosizlshbve6spahju7ryu3gemvqgj7xcjmbyvprkvjaarjasq' #'fxs3qabuylbip2i6s4664tvl5kaqk72unptt2qixx6nrcilhycya' #

$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$filteredbuilds = (Invoke-RestMethod ` -Uri "https://spglobal.visualstudio.com/csd-datapipelines/_apis/build/definitions?api-version=5.1&taskIdFilter=71a9a2d3-a98a-4caa-96ab-affca411ecda" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
$filteredbuildids = $filteredbuilds | select id 
write-host "Total Builds with Visual Studio Task in ContentSystems Project:" $filteredbuildids.Count
write-host $filteredbuildids.Count
for($i = 0;$i-lt $filteredbuildids.Count;$i++)
{
if($i -ge 0 -and $i -lt 300){
$buildnumber = ($filteredbuildids.GetValue($i)).id
write-host $buildnumber
if ($buildnumber -eq 2072) {
write-host "------------------https://spglobal.visualstudio.com/$projectname/_apis/build/definitions/$buildnumber-----------------"
$defresponse = (Invoke-WebRequest ` -Uri "https://spglobal.visualstudio.com/$projectid/_apis/build/Definitions/$buildnumber" -ContentType "application/json" -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" }).Content



[void][System.Reflection.Assembly]::LoadFile("$pwd\Newtonsoft.Json.dll")
$buildDefinition = [Newtonsoft.Json.JsonConvert]::DeserializeObject($defresponse)
write-host "##############Original Definition########################"
$buildDefinition.ToString()
#write-host "######################################"
#$buildDefinition.ToString()
#$buildDefinition = [Newtonsoft.Json.JsonConvert]::SerializeObject($buildDefinition)
#$buildDefinition.ToString()
$version = [Newtonsoft.Json.JsonConvert]::SerializeObject("version")
$steps = $buildDefinition.process.phases.steps
foreach($step in $steps)
{
if('71a9a2d3-a98a-4caa-96ab-affca411ecda' -eq $step.task.id.tostring())
{
$step.tostring()
$step.task.id = "c6c4c611-aa2e-4a33-b606-5eaba2196824"
$step.inputs.add("msbuildLocationMethod",$version)
$step.inputs.add("msbuildVersion",$step.inputs.vsVersion)
$step.inputs.add("msbuildArguments",$step.inputs.msbuildArgs)
$step.inputs.Remove("vsVersion")
$step.inputs.Remove("msbuildArgs")
$step.tostring()
}
}

 

$buildDefinitionUpdated = [Newtonsoft.Json.JsonConvert]::SerializeObject($buildDefinition)

 

$postData = [System.Text.Encoding]::UTF8.GetBytes($buildDefinitionUpdated)
write-host "###############After Update#######################"
$postData.ToString()
# The TFS2015 REST endpoint requires an api-version header, otherwise it refuses to work properly.
$headers = @{ "Authorization" = "Basic $auth";"Accept" = "api-version=5.1" }
$response = Invoke-WebRequest -Uri https://spglobal.visualstudio.com/$projectname/_apis/build/definitions/$buildnumber -Headers $headers `
              -Method Put -Body $postData -ContentType "application/json"
$response.StatusDescription
#$response.Content.ToString()

 


}}
}