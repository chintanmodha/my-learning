﻿#ENVNAME could be dev, stg, prd 

param ([String] $ENVNAME,  
[String] $REGION  
)   

#New-Item -Path $INSTALLATION_WORKING_DIRECTORY -ItemType Directory  
$setupfolder = "C:\Temp\docker_ee_install"
new-item $setupfolder -ItemType directory | Out-null
aws    s3 cp --no-progress  s3://mi1.0-scriptedbootstraps-${REGION}/${ENVNAME}/dockerEE/install_utils.zip $setupfolder
Expand-Archive $setupfolder\install_utils.zip -DestinationPath $setupfolder -Force


$abc = Get-Content -Path C:\Temp\docker_ee_install\Parameters.txt -ReadCount 50 | ForEach-Object {
    $Splat = ConvertFrom-StringData $($_ -join [Environment]::NewLine)
}

<#
$Splat.Keys
#dev/stg/prd
$ENVNAME=$Splat.ENVNAME
#us-east-1
$REGION=$Splat.REGION
#>

$DOCKER_EE_VERION=$Splat.DOCKER_EE_VERION
$UCP_VERSION=$Splat.UCP_VERSION
$INSTALLATION_WORKING_DIRECTORY=$Splat.INSTALLATION_WORKING_DIRECTORY
$UCP_MANAGER_NODE_IP_1=$Splat.UCP_MANAGER_NODE_IP_1
$UCP_MANAGER_NODE_IP_2=$Splat.UCP_MANAGER_NODE_IP_2
$UCP_MANAGER_NODE_IP_3=$Splat.UCP_MANAGER_NODE_IP_3
$UCP_IMAGES_FILENAME=$Splat.UCP_IMAGES_FILENAME
$OS_VERSION=$Splat.OS_VERSION
$UCP_File_EXTENSION=$Splat.UCP_FILE_EXTENSION
$https_proxy=$Splat.https_proxy
$http_proxy=$Splat.http_proxy
$Docker_EE_Source=$Splat.Docker_EE_Source

$UCPArchiveName = $UCP_IMAGES_FILENAME.Replace("UCP_VERSION",$UCP_VERSION)

#Copy files from AWS S3 bucket to local system 

aws    s3 cp --no-progress  s3://mi1.0-scriptedbootstraps-${REGION}/${ENVNAME}/dockerEE/$Docker_EE_Source $INSTALLATION_WORKING_DIRECTORY 
aws    s3 cp --no-progress  s3://mi1.0-scriptedbootstraps-${REGION}/${ENVNAME}/dockerEE/$UCPArchiveName $INSTALLATION_WORKING_DIRECTORY


$Docker_Deployment_Path = 'C:\Program Files'
Expand-Archive $INSTALLATION_WORKING_DIRECTORY$Docker_EE_Source -DestinationPath $Docker_Deployment_Path -Force 

#setup schedule task post restart
$A = New-ScheduledTaskAction  -Execute "C:\Temp\docker_ee_install\dockerinstall.bat" -Argument "$ENVNAME $REGION" #batchfile will call powershell
$T = New-ScheduledTaskTrigger -AtStartup
$S = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries
$taskname = "newtask"
# $D = New-ScheduledTask -Action $A -Trigger $T -Settings $S 


Register-ScheduledTask -TaskName $taskname `
                       -Action $A `
                       -Trigger $T `
                       -User "CIQDEV\dockeree_svc" `
                       -Password 'Wz!d>4~>Ne' `
                       -Settings $S | Out-Null


# Install Docker. This requires rebooting.
$null = Install-WindowsFeature containers 

Restart-Computer

<# --------Hardcoded for debugging --------





#dev/stg/prd 
$ENVNAME="dev" 

#us-east-1 
$REGION="us-east-1" 
 

#Copy ,ini file from AWS 

#########    aws    s3 cp --no-progress  s3://mi1.0-scriptedbootstraps-${REGION}/${ENVNAME}/dockerEE/InstallAndConfigureDockerEE.ini 'C:\Program Files\docker' 

#Read values from .ini file and assign in variables 

#------------To be started--------- 

 

 

$DOCKER_EE_VERION="18.09.3" 
$UCP_VERSION="3.1.6" 
$INSTALLATION_WORKING_DIRECTORY="C:\Temp\docker_ee_install\" 

# dev: https://storebits.docker.com/ee/m/sub-431bb6b9-b64c-462a-ae85-27452ebb9b24/rhel" 
# staging: https://storebits.docker.com/ee/m/sub-5bd5e757-da0d-4ebe-8b5c-bf71a150e925/rhel" 
# prod: https://storebits.docker.com/ee/m/sub-5cb5648a-9e45-493b-85da-6dc4fa7c864b/rhel" 
#$DOCKER_EE_REPO_URL="https://storebits.docker.com/ee/m/sub-431bb6b9-b64c-462a-ae85-27452ebb9b24/rhel" 
<#
$UCP_URL="ucp.midev.spglobal.com" 
$DTR_URL="dtr.midev.spglobal.com" 
$UCP_USER="deploy-test_svc"#"spgmiadmin" 
$UCP_PW="1 mouse in DEV house!"#"<REDACTED>" 
#>

$UCP_MANAGER_NODE_IP_1="172.22.32.184" 
$UCP_MANAGER_NODE_IP_2="172.22.32.185" 
$UCP_MANAGER_NODE_IP_3="172.22.32.186" 

$CONTAINERD_IO_RPM="containerd.io-1.2.4-3.1.el7.x86_64.rpm" 
$SELINUX_RPM="container-selinux-2.68-1.el7.noarch.rpm" 
$DOCKER_CLI_RPM="docker-ee-cli-18.09.3-3.el7.x86_64.rpm" 
$DOCKER_RPM="docker-ee-18.09.3-3.el7.x86_64.rpm" 

$UCP_IMAGES_FILENAME="ucp_images_win_2016_$UCP_VERSION.tar.gz" 

#http://squidnat-av.marketintelligence.spglobal.com:3128 

$https_proxy="" 
$http_proxy="" 

$Docker_EE_Source="docker-win-18-09-3.zip" 
$psPostbootscriptfile = "postboot

#--------------To be ended--------- 



#Create Temporary Installation working directory to copy files from S3 bucket 

#New-Item -Path $INSTALLATION_WORKING_DIRECTORY -ItemType Directory  

aws    s3 cp --no-progress  s3://mi1.0-scriptedbootstraps-${REGION}/${ENVNAME}/dockerEE/InstallAndConfigureDockerEE.ini $INSTALLATION_WORKING_DIRECTORY 

#Copy files from AWS S3 bucket to local system 

aws    s3 cp --no-progress  s3://mi1.0-scriptedbootstraps-${REGION}/${ENVNAME}/dockerEE/daemon.json $INSTALLATION_WORKING_DIRECTORY 

aws    s3 cp --no-progress  s3://mi1.0-scriptedbootstraps-${REGION}/${ENVNAME}/dockerEE/$CONTAINERD_IO_RPM $INSTALLATION_WORKING_DIRECTORY 

aws    s3 cp --no-progress  s3://mi1.0-scriptedbootstraps-${REGION}/${ENVNAME}/dockerEE/$SELINUX_RPM $INSTALLATION_WORKING_DIRECTORY 

aws    s3 cp --no-progress  s3://mi1.0-scriptedbootstraps-${REGION}/${ENVNAME}/dockerEE/$DOCKER_CLI_RPM $INSTALLATION_WORKING_DIRECTORY 

aws    s3 cp --no-progress  s3://mi1.0-scriptedbootstraps-${REGION}/${ENVNAME}/dockerEE/$DOCKER_RPM $INSTALLATION_WORKING_DIRECTORY 

#For Below Image AWS S3 bucket needs to be updated - Done By Mustakim - Can we have Separate Subfolder for Windows Sources / images

aws    s3 cp --no-progress  s3://mi1.0-scriptedbootstraps-${REGION}/${ENVNAME}/dockerEE/$UCP_IMAGES_FILENAME $INSTALLATION_WORKING_DIRECTORY 




#Set Availability Zone of Target Machine 

$EC2_AVAIL_ZONE = Invoke-RestMethod -Uri http://169.254.169.254/latest/meta-data/placement/availability-zone -Method Get 
switch ($EC2_AVAIL_ZONE)  
{  
"us-east-1a" {$DIR_SRC="10.24.76.75"}  
"us-east-1b" {$DIR_SRC="10.24.79.180"}  
"us-east-1c" {$DIR_SRC="10.24.78.155"}  
}  


$DIR_TGT = “nfs_share”  
New-Item -Path $DIR_TGT -ItemType Directory 

$Docker_Deployment_Path = 'C:\Program Files' 
Expand-Archive $INSTALLATION_WORKING_DIRECTORY$Docker_EE_Source -DestinationPath $Docker_Deployment_Path -Force 

# Install Docker. This requires rebooting.
$null = Install-WindowsFeature containers 



 

 ENVNAME=dev
REGION=us-east-1
DOCKER_EE_VERION=18.09.3
UCP_VERSION=3.1.6
INSTALLATION_WORKING_DIRECTORY=C:\\Temp\\docker_ee_install\\
UCP_MANAGER_NODE_IP_1=172.22.32.184
UCP_MANAGER_NODE_IP_2=172.22.32.185
UCP_MANAGER_NODE_IP_3=172.22.32.186
CONTAINERD_IO_RPM=containerd.io-1.2.4-3.1.el7.x86_64.rpm
SELINUX_RPM=container-selinux-2.68-1.el7.noarch.rpm
DOCKER_CLI_RPM=docker-ee-cli-18.09.3-3.el7.x86_64.rpm
DOCKER_RPM=docker-ee-18.09.3-3.el7.x86_64.rpm
UCP_IMAGES_FILENAME=ucp_images_win
https_proxy=
http_proxy=
Docker_EE_Source=docker-win-18-09-3.zip