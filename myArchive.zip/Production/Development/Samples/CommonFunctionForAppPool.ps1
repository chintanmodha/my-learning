Function stopAppPool( [String]$ServerName,[string]$appPoolName)
    {

	  [System.Reflection.Assembly]::LoadWithPartialName(“Microsoft.Web.Administration”)
        $objServer = [Microsoft.Web.Administration.ServerManager]::OpenRemote($ServerName)
        $status = $objServer.ApplicationPools[$appPoolName].State
       
       if($status -ne 'Stopped')

       {
        $objServer.ApplicationPools[$appPoolName].Stop()     

       }
           do
       {
       $status = $objServer.ApplicationPools[$appPoolName].State
       }while ($status -ne 'Stopped')
       $status
       ##QueryAppPool $objServer $ServerName $appPoolName
       #Write-Host "---------------------"
       #Write-Host "$appPoolName on $ServerName is $status"
    }