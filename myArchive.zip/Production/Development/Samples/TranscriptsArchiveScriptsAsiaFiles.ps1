﻿# Bucket region details
$credsCSV = Get-ChildItem "D:\CapitalIQ\Services\TranscriptsArchiveScriptsAsiaFiles\GetAccessKeys.csv" 
$credsContent = Import-Csv $credsCSV.FullName -Delimiter :

$RegionEndpoint = $credsContent.RegionEndpoint
$accessKeyID = $credsContent.AccesskeyID
$secretAccessKey = $credsContent.Secretaccesskey



Initialize-AWSDefaultConfiguration -Region $RegionEndpoint -AccessKey $accessKeyID -SecretKey $secretAccessKey

 
$s3Bucket = "mi-prd-transcripts-scriptsasiaphysicalfiles"
$sourceFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\EngAudioFiles"
$targetFolder = "s3://mi-prd-transcripts-scriptsasiaphysicalfiles/EventsFromVendors_PhysicalFiles/EngAudioFiles"

aws s3 sync $sourceFolder $targetFolder
#aws s3 ls

$sourceFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\EngJSON"
$targetFolder = "s3://mi-prd-transcripts-scriptsasiaphysicalfiles/EventsFromVendors_PhysicalFiles/EngJSON"

aws s3 sync $sourceFolder $targetFolder

$sourceFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\EngPDFs"
$targetFolder = "s3://mi-prd-transcripts-scriptsasiaphysicalfiles/EventsFromVendors_PhysicalFiles/EngPDFs"

aws s3 sync $sourceFolder $targetFolder

$sourceFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\EngQAndA"
$targetFolder = "s3://mi-prd-transcripts-scriptsasiaphysicalfiles/EventsFromVendors_PhysicalFiles/EngQAndA"

aws s3 sync $sourceFolder $targetFolder

$sourceFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\EngRawTranscript"
$targetFolder = "s3://mi-prd-transcripts-scriptsasiaphysicalfiles/EventsFromVendors_PhysicalFiles/EngRawTranscript"

aws s3 sync $sourceFolder $targetFolder

$sourceFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\EngSATranscript"
$targetFolder = "s3://mi-prd-transcripts-scriptsasiaphysicalfiles/EventsFromVendors_PhysicalFiles/EngSATranscript"

aws s3 sync $sourceFolder $targetFolder

$sourceFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\EngXMLs"
$targetFolder = "s3://mi-prd-transcripts-scriptsasiaphysicalfiles/EventsFromVendors_PhysicalFiles/EngXMLs"

aws s3 sync $sourceFolder $targetFolder


$sourceFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\LocalAudioFiles"
$targetFolder = "s3://mi-prd-transcripts-scriptsasiaphysicalfiles/EventsFromVendors_PhysicalFiles/LocalAudioFiles"

aws s3 sync $sourceFolder $targetFolder

$sourceFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\LocalJSON"
$targetFolder = "s3://mi-prd-transcripts-scriptsasiaphysicalfiles/EventsFromVendors_PhysicalFiles/LocalJSON"

aws s3 sync $sourceFolder $targetFolder

$sourceFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\LocalPDFs"
$targetFolder = "s3://mi-prd-transcripts-scriptsasiaphysicalfiles/EventsFromVendors_PhysicalFiles/LocalPDFs"

aws s3 sync $sourceFolder $targetFolder

$sourceFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\LocalQAndA"
$targetFolder = "s3://mi-prd-transcripts-scriptsasiaphysicalfiles/EventsFromVendors_PhysicalFiles/LocalQAndA"

aws s3 sync $sourceFolder $targetFolder

$sourceFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\LocalRawTranscript"
$targetFolder = "s3://mi-prd-transcripts-scriptsasiaphysicalfiles/EventsFromVendors_PhysicalFiles/LocalRawTranscript"

aws s3 sync $sourceFolder $targetFolder

$sourceFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\LocalSATranscript"
$targetFolder = "s3://mi-prd-transcripts-scriptsasiaphysicalfiles/EventsFromVendors_PhysicalFiles/LocalSATranscript"

aws s3 sync $sourceFolder $targetFolder

$sourceFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\LocalXMLs"
$targetFolder = "s3://mi-prd-transcripts-scriptsasiaphysicalfiles/EventsFromVendors_PhysicalFiles/LocalXMLs"

aws s3 sync $sourceFolder $targetFolder


$DeletedLogFolder = "D:\CapitalIQ\Services\EventsFromVendors_PhysicalFiles\DeletedFilesLog"

$FileName = "DeletedLog" + (Get-Date).tostring(“dd-MM-yyyy”) + “.txt”
$DeletedFileName = $DeletedLogFolder + "\" + $FileName

if (!(Test-Path $DeletedFileName))
{
    New-Item -itemType File -Path $DeletedLogFolder -Name ($FileName)
}
#Delete files older than 2 months
Get-ChildItem $sourceFolder -Recurse -Force -ea 0 |
? {!$_.PsIsContainer -and $_.LastWriteTime -lt (Get-Date).AddDays(-360)} |
ForEach-Object {
   $_ | del -Force
   $_.FullName | Out-File $DeletedLogFolder\$FileName -Append
}

