﻿
param ([String] $ENVNAME,  
[String] $REGION  
)   

$abc = Get-Content -Path C:\Temp\docker_ee_install\Parameters.txt -ReadCount 50 | ForEach-Object {
    $Splat = ConvertFrom-StringData $($_ -join [Environment]::NewLine)
}

<#
$Splat.Keys
#dev/stg/prd
$ENVNAME=$Splat.ENVNAME
#us-east-1
$REGION=$Splat.REGION
#>

$DOCKER_EE_VERION=$Splat.DOCKER_EE_VERION
$UCP_VERSION=$Splat.UCP_VERSION
$INSTALLATION_WORKING_DIRECTORY=$Splat.INSTALLATION_WORKING_DIRECTORY
$UCP_MANAGER_NODE_IP_1=$Splat.UCP_MANAGER_NODE_IP_1
$UCP_MANAGER_NODE_IP_2=$Splat.UCP_MANAGER_NODE_IP_2
$UCP_MANAGER_NODE_IP_3=$Splat.UCP_MANAGER_NODE_IP_3
$UCP_IMAGES_FILENAME=$Splat.UCP_IMAGES_FILENAME
$OS_VERSION=$Splat.OS_VERSION
$UCP_File_EXTENSION=$Splat.UCP_FILE_EXTENSION
$https_proxy=$Splat.https_proxy
$http_proxy=$Splat.http_proxy
$Docker_EE_Source=$Splat.Docker_EE_Source

$UCPArchiveName = $UCP_IMAGES_FILENAME.Replace("UCP_VERSION",$UCP_VERSION)

#Set Environment Variable 

$newPath = "$env:ProgramFiles\docker;" + 
[Environment]::GetEnvironmentVariable("PATH", 
[EnvironmentVariableTarget]::Machine) 

[Environment]::SetEnvironmentVariable("PATH", $newPath, 
[EnvironmentVariableTarget]::Machine) 
 

## Create the Docker daemon as a service. 

# Going to root folder
cd\ 

#Path into actual directory where dockerd exe is located 

CD "$env:ProgramFiles\docker"
.\dockerd --register-service 

Start-Service docker 
 

#Install UCP offline 
.\docker load -i $INSTALLATION_WORKING_DIRECTORY$UCPArchiveName #ucp_images_win_2019_3.1.6.tar.gz 

$script = [ScriptBlock]::Create((.\docker run --rm docker/ucp-agent-win:$UCP_VERSION windows-script | Out-String))
Invoke-Command $script 

#To Check which UCP Node is UP
If ((Test-Connection $UCP_MANAGER_NODE_IP_1 -Quiet) -eq $true)
{
$managernode = $UCP_MANAGER_NODE_IP_1
}
elseif ((Test-Connection $UCP_MANAGER_NODE_IP_2 -Quiet) -eq $true)
{
$managernode = $UCP_MANAGER_NODE_IP_2
}
elseif((Test-Connection $UCP_MANAGER_NODE_IP_3 -Quiet) -eq $true)
{
$managernode = $UCP_MANAGER_NODE_IP_3
}
else
{
write-host "All manager nodes seem to be down!"
}

#Getting Swarm-JoinToken Dynamically

Body = '{"username":"svc_aws_automation_admin_dev","password":"a@5ed46jh@4"}'
$AUTHTOKEN=((Invoke-WebRequest -Body $Body -Uri $URI/auth/login -Method POST).Content)|ConvertFrom-Json|select auth_token -ExpandProperty auth_token
$a = (Invoke-WebRequest -Uri $URI/swarm -ContentType "application/json" -Headers @{"Authorization"="Bearer $AUTHTOKEN"}).content|ConvertFrom-Json|Select JoinTokens
$SwarmJoinWorkerToken = $a.JoinTokens.Worker
.\docker swarm join --token $SwarmJoinWorkerToken $managernode:2377

#.\docker swarm join --token SWMTKN-1-0doqnjr1xmo1qhs17eczrqixirz51nx3hb7npk8l7xnmwcxv4v-cj0qiyzhharw8us2t2k5in0q0 172.22.32.184:2377 

