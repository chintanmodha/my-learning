﻿$appcmd = "c:\windows\system32\inetsrv\appcmd.exe"
&$appcmd /?  #help

#list all sites
&$appcmd list site
&$appcmd list site /xml        #use xml to get attribute names
&$appcmd list site /text:name  #use text to get attribute values

&$appcmd list site /text:name | sort  #ps sort

#list all app pools
&$appcmd list apppool

#list app pool names
&$appcmd list apppool /text:name

#list app pool .net framework version
&$appcmd list apppool /text:managedRuntimeVersion

#list all w3wp.exe worker processes, use to debug match process id to iis website
&$appcmd list wp

#list started sites, running
&$appcmd list site /state:started

#list stopped app pools
&$appcmd list apppool /state:stopped

#list all virtual directory/physical paths
&$appcmd list vdir

#list site bindings ipaddress
(&$appcmd list site prod /text:bindings).split(",")

#list response headers
&$appcmd list config prod /section:httpProtocol

#add response headers
&$appcmd set config prod /section:httpProtocol /+"customHeaders.[name='foo', value='bar']"

#delete response headers
&$appcmd set config prod /section:httpProtocol /-"customHeaders.[name='foo']"
&$appcmd set config prod /section:httpProtocol /-"customHeaders.[name='x-powered-by']"

#output site configuration text
&$appcmd list site prod /text:*

#list website virtual directory/physical path
&$appcmd list vdir prod/

#stop website
&$appcmd stop apppool prod; &$appcmd stop site prod

#start website
&$appcmd start apppool prod; &$appcmd start site prod

#stop all running sites
&$appcmd list site /state:started /xml | &$appcmd stop site /in  

#stop all running app pools
&$appcmd list apppool /state:started /xml | &$appcmd stop apppool /in

#list mime types
&$appcmd list config prod /section:system.webServer/staticContent