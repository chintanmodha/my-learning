﻿#clear conent of any folder along with subfloders
function cleanupbackupfolder ([String] $backupfolderpath){
$emptydirectory = "\\snltscso\D$\CMTest\Powershelltest\DataProcessing\Empty"
robocopy $emptydirectory $backupfolderpath /purge
}
#taking backup in same folder excluding folder matching pattern
function backupwithindeploymentfolder ([String] $source,[String] $exclude){
$destination = $source+"\Backup"

write-host "Files are required to be copied from $source to $destination excluding content of folders contains $exclude"
cleanupbackupfolder $destination
RoboCopy $source $destination /E /XD $exclude
}

#Check One\Multiple Service(s) on same Server
function checkMultiServices([String]$ServerName,[String]$ServiceName)
{
$service = $ServiceName.Split(";")
for($i=0;$i-lt$service.Count;$i++){
$status = (get-service -ComputerName $ServerName -Name $service[$i]).Status
Write-Host $service[$i] " on $ServerName is $status"
}
}

#Start One\Multiple Service(s) on same Server
function startMultiServices([String]$ServerName,[String]$ServiceName)
{
$service = $ServiceName.Split(";")
for($i=0;$i-lt$service.Count;$i++){

$status = (get-service -ComputerName $ServerName -Name $service[$i]).status
Write-Host $service[$i] " on $ServerName is $status"

if ($status -eq "Stopped") {
(get-service -ComputerName $ServerName -Name $service[$i]).Start()
}
do
{
$status = (get-service -ComputerName $ServerName -Name $service[$i]).status
}while ($status -ne "Running" )
Write-Host "---------------------"
Write-Host $service[$i] " on $ServerName is $status"
}
Start-Sleep -s 5
}

#Stop One\Multiple Service(s) on same Server
function stopMultiServices([String]$ServerName,[String]$ServiceName)
{
$service = $ServiceName.Split(";")
for($i=0;$i-lt$service.Count;$i++){

$status = (get-service -ComputerName $ServerName -Name $service[$i]).status
Write-Host $service[$i] " on $ServerName is $status"

if ($status -eq "Running") {
(get-service -ComputerName $ServerName -Name $service[$i]).Stop()
}
do
{
$status = (get-service -ComputerName $ServerName -Name $service[$i]).status
}while ($status -ne "Stopped" )
Write-Host "---------------------"
Write-Host $service[$i] " on $ServerName is $status"
}Start-Sleep -s 5
}

# To Copy Files from Source to Destination  (With filters and number of days)
function copyFiles([String]$source,[String]$destination,[String[]] $filters = "*.*" ,[int] $days=10)
{

$spath = $source.Split(";")
$dpath = $destination.Split(";")
if($spath.count -eq $dpath.count)
{
for($i=0;$i-lt$spath.count;$i++){
$days = $days * -1
$filepath = $spath[$i] + "\*.*"


If (!(Test-Path $dpath[$i])) {
 
   New-Item -Path $dpath[$i] -ItemType Directory
   }
foreach($filter in $filters)  #$filters should be passed as @("value1","value2")
{

Copy-Item -Path $filepath -Force -filter $filter -Destination $dpath[$i] -ErrorAction Inquire

}
$newfilecount =  (Get-ChildItem -Path $dpath[$i]  -Filter *.* | ? { $_.LastWriteTime -gt (Get-Date).AddDays($days)}).Count
#return $newfilecount
}}
else
{
Write-Host "Source and Destination Path counts are not matching"
}
}

function verifyFiles([String] $destinationpath, [String] $keyword, [String] $excludefolder)
{
$pathcount = $destinationpath.Split(";").Count
$keyword = "*" + $keyword +"*"
For ($i = 0; $i -lt $pathcount;$i++)
{
$dpath = $destinationpath.Split(";")[$i]
#Get-ChildItem -Recurse -Path $dpath -Include $keyword -File | Where-Object {$_.PSParentPath -notlike $excludefolder}
Get-ChildItem -Recurse -Path $dpath -Include $keyword -File | Where-Object {$_.PSParentPath -notmatch $excludefolder}
}
}

function verifyMultipleFiles([String] $destinationpath, [String] $keyword, [String] $excludefolder)
{
$pathcount = $destinationpath.Split(";").Count
$filecount = $keyword.Split(";").Count

#$keyword = "*" + $keyword +"*"

For ($j=0;$j -lt $filecount;$j++)
{
$files.Insert($j, "*" + $keyword.Split(";")[$j]  +"*")
}

For ($i = 0; $i -lt $pathcount;$i++)
{
$dpath = $destinationpath.Split(";")[$i]

#Get-ChildItem -Recurse -Path $dpath -Include $keyword -File | Where-Object {$_.PSParentPath -notlike $excludefolder}
#Get-ChildItem -Recurse -Path $dpath -Include $keyword -File | Where-Object {$_.PSParentPath -notmatch $excludefolder}
Write-Host $files
#Get-ChildItem -Recurse -Path $dpath -Include $files -File | Where-Object {$_.PSParentPath -notmatch $excludefolder}
}
}


# Web Application Pool Management
#To Start Application Pool

    Function startAppPool ( [String]$ServerName,[string]$appPoolName)
    {

	 [System.Reflection.Assembly]::LoadWithPartialName(“Microsoft.Web.Administration”)
        $objServer = [Microsoft.Web.Administration.ServerManager]::OpenRemote($ServerName)
        $status = $objServer.ApplicationPools[$appPoolName].State
       
       if($status -ne 'Started')

       {
        $objServer.ApplicationPools[$appPoolName].Start()
       }

       do
       {
       $status = $objServer.ApplicationPools[$appPoolName].State
       }while ($status -ne 'Started')
       QueryAppPool $objServer $ServerName $appPoolName
       #Write-Host "---------------------"
       #Write-Host "$appPoolName on $ServerName is $status"
       

    }
    

#To Stop Application Pool

    Function stopAppPool( [String]$ServerName,[string]$appPoolName)
    {

	  [System.Reflection.Assembly]::LoadWithPartialName(“Microsoft.Web.Administration”)
        $objServer = [Microsoft.Web.Administration.ServerManager]::OpenRemote($ServerName)
        $status = $objServer.ApplicationPools[$appPoolName].State
       
       if($status -ne 'Stopped')

       {
        $objServer.ApplicationPools[$appPoolName].Stop()     

       }
           do
       {
       $status = $objServer.ApplicationPools[$appPoolName].State
       }while ($status -ne 'Stopped')
       QueryAppPool $objServer $ServerName $appPoolName
       #Write-Host "---------------------"
       #Write-Host "$appPoolName on $ServerName is $status"
    }


    #To Get Status of Application Pool

Function QueryAppPool( [Microsoft.Web.Administration.ServerManager]$serverObject,[String] $serverName,[string]$appPoolName)
    {	  
        $status = $serverObject.ApplicationPools[$appPoolName].State
        Write-Host "---------------------"
        Write-Host "$appPoolName on $serverName is $status"
    }
Function getFileCount([String] $dpaths, [int] $days=-1000)
    {
    $pathcount = $dpaths.Split(";").Count
    #$dpath = $dpaths.Split(";")
    for ($i = 0; $i -lt $pathcount; $i++)
    {
        $dpath = $dpaths.Split(";")[$i].ToString()
        Write-Host "FileCount at $dpath :" (Get-ChildItem -Path $dpath  -Filter *.* | ? { $_.LastWriteTime -gt (Get-Date).AddDays($days)}).Count
    }
    }

# To get live server name 
function liveServer([String] $servercommonname)
{
try {
return (Resolve-DnsName $servercommonname -ErrorAction Stop).NameHost.Split(".")[0]
}
catch {
return $servercommonname
}
} 


function selectfiles([String] $filepath)
{

     $initialDirectory = "\\snl\files\snlcentral\ctsstage"
     if( $filepath -ne ""){
     $initialDirectory = $filepath
     }

    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null
    $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $OpenFileDialog.initialDirectory = $initialDirectory
    #$OpenFileDialog.filter = "*.config"
    $OpenFileDialog.Multiselect = $true
    $OpenFileDialog.ShowDialog()
    #$OpenFileDialog.
    #write-host $OpenFileDialog.FileNames.Count
    [String[]] $filelist =  $OpenFileDialog.SafeFileNames
    return $filelist

}

function simplecopy([String]$source,[String] $destination, [String[]] $files)
{
robocopy $source $destination $files
}