﻿#List Subscriptions

function getprojectidapi5.1 ([string] $projectname,[string] $pat,[string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$projectlist = (Invoke-RestMethod ` -Uri "$baseurl/_apis/projects?api-version=5.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
$projectid = $projectlist | select id,name | where name -eq $projectname
return $projectid.id
}

function getprojectlistapi5.1 ([string] $pat,[string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$projectlist = (Invoke-RestMethod ` -Uri "$baseurl/_apis/projects?api-version=5.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
return $projectlist
}
function getbuildids5.1 ([string] $projectname,[string] $pat,[string] $taskid, [string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
 if ($taskid.Length -gt 0)
  { $url = "$baseurl/$projectname/_apis/build/definitions?api-version=5.1&taskIdFilter=$taskid" }
 else
  { $url = "$baseurl/$projectname/_apis/build/definitions?api-version=5.1" }

$buildids = (Invoke-RestMethod ` -Uri "$url" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=5.1-preview.2" } ` -Method Get ` -ContentType "application/json" ).value  
return $buildids
}
function getbuilddefinition5.1 ([string] $projectid ,[string] $pat,[string] $buildid, [string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
#$url = "https://spglobal.visualstudio.com/contentsystems/_apis/build/definitions/1573?api-version=5.1"
$url = "$baseurl/$projectid/_apis/build/definitions/$buildid"
#write-host $url
$builddefinition = (Invoke-WebRequest -Uri $url -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).content  
return $builddefinition
}
clear
$baseurl="https://spglobal.visualstudio.com"
$taskid = 'e213ff0f-5d5c-4791-802d-52ea3e7be1f1'
$pat = 'p2iwv5wnrj72kydprlnfgpvgvwrycwqhsvxrdfm5wu6m2priko4a' # 'snnnawp2tl7yz6c7ptq6lelw72abvoazs7qrn6ofue3bdhe2ryaq'# 'jokosizlshbve6spahju7ryu3gemvqgj7xcjmbyvprkvjaarjasq' 'jokosizlshbve6spahju7ryu3gemvqgj7xcjmbyvprkvjaarjasq' #
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$sea
$projectlist =  getprojectlistapi5.1 $pat
foreach($project in $projectlist)
{
$projectname = $project.name
$projectid = getprojectidapi5.1 $projectname $pat
#write-host "$projectid ---- $projectname"

#$projectname = 'ContentSystems'
 
$buildids = getbuildids5.1 $projectname $pat $taskid

#(Invoke-RestMethod ` -Uri "https://spglobal.visualstudio.com/$projectname/_apis/build/definitions?api-version=5.1&taskIdFilter=$taskid" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=5.1-preview.2" } ` -Method Get ` -ContentType "application/json" ).value  

[void][System.Reflection.Assembly]::LoadFile("$pwd\Newtonsoft.Json.dll")
$validbuildcount = 0
foreach($build in $buildids)
{
$script = ""
$buildID = $build.id.ToString()

$defresponse = getbuilddefinition5.1 $projectid $pat $buildID
$buildDefinition = [Newtonsoft.Json.JsonConvert]::DeserializeObject($defresponse)
#$buildDefinition.ToString()

$script = $buildDefinition.ToString()
if( $script -match 'Agent.Name -equals')
{
write-host -ForegroundColor Green "$baseurl/$projectname/_apps/hub/ms.vss-ciworkflow.build-ci-hub?_a=edit-build-definition&id=$buildID"

}

}

}
