﻿#List Subscriptions
function getprojectidapi5.1 ([string] $projectname,[string] $pat,[string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$projectlist = (Invoke-RestMethod ` -Uri "$baseurl/_apis/projects?api-version=5.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
$projectid = $projectlist | select id,name | where name -eq $projectname
return $projectid.id
}
#clear
$projectname = 'SNLServiceModules'
#$projectid = '0d845a76-0046-4253-84c4-ccc77a3ea325'
$pat = 'dvclshmpwhbkoeqbcecpawbsmuwmddk4oaay26uivologeybdfkq'
$dynamicprojectid = getprojectidapi5.1 $projectname $pat
$targetprojectname = 'DevOps Shared Framework'
$targetprojectid = getprojectidapi5.1 $targetprojectname $pat

$subscriptions = Invoke-RestMethod ` -Uri "https://spglobal.visualstudio.com/_apis/hooks/subscriptions?api-version=6.0-preview.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=6.0-preview.1" } ` -Method Get `

[void][System.Reflection.Assembly]::LoadFile("$pwd\Newtonsoft.Json.dll")

foreach($subscription in $subscriptions)
{
if($subscription.consumerID -eq 'datadog' -and $subscription.publisherInputs.projectID -eq $dynamicprojectid)
{
write-host "Writing event type"$subscription.eventType
#write-host "PublisherID -" $subscription.publisherId
#write-host "eventType -" $subscription.eventType
#write-host "consumerId -" $subscription.consumerId
#write-host "consumerActionId -" $subscription.consumerActionId
#write-host "PublisherInputs.buildStatus -" $subscription.publisherInputs.buildStatus
#write-host "PublisherInputs.definitionName -" $subscription.publisherInputs.definitionName
#write-host "------------"
if ($subscription.eventType -eq 'ms.vss-release.release-abandoned-event')
{
write-host "------Original Source---------"
$subscription
$subID = $subscription.id.ToString()
#write-host "------$subscriptionID"
#$url = "https://spglobal.visualstudio.com/_apis/hooks/subscriptions/$subID?api-version=6.0-preview.1"
$url2 = $subscription.url

#write-host "$url"
write-host "$url2"

#$subresponse = (Invoke-WebRequest -Uri "$url"  -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=6.0-preview.1" } -ContentType "application/json").Content
$subresponse = (Invoke-WebRequest -Uri "$url2"  -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=6.0-preview.1" } -ContentType "application/json").Content

$subscription = [Newtonsoft.Json.JsonConvert]::DeserializeObject($subresponse)

write-host "----------Before Change----------"
$subscription.tostring()

$subscription.Remove("id")
$subscription.Remove("url")
$subscription.Remove("createdDate")
$subscription.Remove("createdBy")
$subscription.Remove("modifiedDate")
$subscription.Remove("modifiedBy")
$subscription.Remove("_links")
$projid = $targetprojectid.ToString()
$subscription.publisherInputs.projectId = $projid

write-host "----------After Change----------"
$subscription.tostring()


$newsubbody = [Newtonsoft.Json.JsonConvert]::SerializeObject($subscription)
<#####
pause
pause
$postData = [System.Text.Encoding]::UTF8.GetBytes($newsubbody)
# The TFS2015 REST endpoint requires an api-version header, otherwise it refuses to work properly.
$headers = @{ "Authorization" = "Basic $auth";"Accept" = "api-version=5.1" }
$response = Invoke-RestMethod -Uri https://spglobal.visualstudio.com/_apis/hooks/subscriptions?api-version=6.0-preview.1 -Headers $headers `
              -Method POST -Body $postData -ContentType "application/json"
$response.status
######>

}

}

}
