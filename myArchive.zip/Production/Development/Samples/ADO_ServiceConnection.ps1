﻿    $targetprojectname = "ContentSystems" #"$(TargetProjectName)"
    $pat = 'n74tsn65kga5nc45pvdfondaiwidkj2kjuygaosartq55qe6qw5a' #"$(PAT)" 
    $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
    $env = "Internal" #"${{parameters.container_env}}"
    $method = "POST"
    function getprojectidapi5.1 ([string] $projectname,[string] $pat,[string] $baseurl="https://spglobal.visualstudio.com")
    {
    $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
    $projectlist = (Invoke-RestMethod ` -Uri "$baseurl/_apis/projects?api-version=5.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
    $projectid = $projectlist | select id,name | where name -eq $projectname
    return $projectid.id
    }
    function getserviceconnectionbyname ([string] $pat,[string] $targetprojectname,[string] $serviceconnectionname)
    {
    $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
    $sc = (Invoke-RestMethod ` -Uri "https://dev.azure.com/spglobal/$targetprojectname/_apis/serviceendpoint/endpoints?endpointNames=$serviceconnectionname&api-version=6.0-preview.4" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
    return $sc
    }
    $targetprojectid = getprojectidapi5.1 $targetprojectname $pat
    switch ($env)
    {
    "Internal"
    {$dtr_env = "dtr-internal-dev"}
    #$dtr_env = "dtr-internal-dev;dtr-internal-stage;dtr-internal-prod"}
    "DMZ"{$dtr_env = "dtr-dmz-dev;dtr-dmz-stage;dtr-dmz-prod"}
    }
    # $dtr_env = "dtr-dmz-dev;dtr-dmz-stage;dtr-dmz-prod"
    $dtrs = $dtr_env.Split(";")
    $serviceconnectionname = ""
    $registry = ""
    $username = ""
    
    #for($i = 0;$i -lt $dtrs.Count; $i++)
    foreach($dtr in $dtrs)
    {
      switch ($dtr)
      {
       "dtr-dmz-dev"
        {
        $serviceconnectionname = "$dtr"
        $registry = "https://dtr.midev.spglobal.com"
        $password = "$(dtr_password_dev)"
        $username= "$(dtr_username_dev)"
        }
       "dtr-dmz-stage"
        {
        $serviceconnectionname = "$dtr"
        $registry = "https://dtr.mistage.spglobal.com"
        $password = "$(dtr_password_stg)"
        $username= "$(dtr_username_stg)"
        }
       "dtr-dmz-prod"
        {
        $serviceconnectionname = "$dtr"
        $registry = "https://dtr.mi.spglobal.com"
        $password = "$(dtr_password_prd)"
        $username= "$(dtr_username_prd)"
        }
        "dtr-internal-dev"
        {
        $serviceconnectionname = "$dtr"
        $registry = "https://dtr-dev.mhf.mhc"
        $password = "xxx"
        $username= "aaa"
        }
       "dtr-internal-stage"
        {
        $serviceconnectionname = "$dtr"
        $registry = "https://dtr-stg.mhf.mhc"
        $password = "xxx_stage"
        $username= "aaa_stage"
        }
       "dtr-internal-prod"
        {
        $serviceconnectionname = "$dtr"
        $registry = "https://dtr.mhf.mhc"
        $password = "xxx_prod"
        $username= "aaa_prod"
        }
      }
    
     $body = @{
      "data"= @{
        "registrytype"="Others"; 
         };
      "name"= "$serviceconnectionname";
      "type"= "dockerregistry";
      "url"= "https://management.azure.com/";
      "authorization"= @{
          "parameters"= @{
              "registry"= "$registry";
              "username"= "$username";
              "password"= "$password";
                    };
          "scheme"= "UsernamePassword"
              };
      "isShared"= "false";
      "isReady"= "true";
      "serviceEndpointProjectReferences"= @(
              @{
             "projectReference"= @{
                "id"= "$targetprojectid";
                "name"= "$targetprojectname"
                   };
             "name"= "$serviceconnectionname"
                 }
                 )
          }
    $json = $body | convertto-json -Depth 3
    write-host "$json"
    $sc = getserviceconnectionbyname $pat $targetprojectname $serviceconnectionname
    if($sc.name -ne "")
    {
      $scid = $sc.id
      $scname = $sc.name
      write-host "$scname - $scid"
      write-host "ServiceConnection - $scname already exists."
      write-host "Updating existing $scname"
      $postURL = "https://spglobal.visualstudio.com/_apis/serviceendpoint/endpoints/$scid"
      write-host "Updated URL - $postURL"
      $method = "PUT"

    }
    else
    {
    $postURL = "https://spglobal.visualstudio.com/_apis/serviceendpoint/endpoints"
    }

    $postData = [System.Text.Encoding]::UTF8.GetBytes($json)
     # The TFS2015 REST endpoint requires an api-version header, otherwise it refuses to work properly.
    $headers = @{ "Authorization" = "Basic $auth";"Accept" = "api-version=6.0-preview.4" }
    $response = Invoke-RestMethod -Uri $postURL -Headers $headers `
                 -Method $method -Body $postData -ContentType "application/json"
    $response
    $response.status
    
    }