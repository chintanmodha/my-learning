﻿#ADO_Fucntions
### GET ProjectID for ProjectName
function getprojectidapi5.1 ([string] $projectname,[string] $pat,[string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$projectlist = (Invoke-RestMethod ` -Uri "$baseurl/_apis/projects?api-version=5.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
$projectid = $projectlist | select id,name | where name -eq $projectname
return $projectid.id
}
### GET ProjectList
function getprojectlistapi5.1 ([string] $pat,[string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$projectlist = (Invoke-RestMethod ` -Uri "$baseurl/_apis/projects?api-version=5.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
return $projectlist
}
### GET Build List (All or Filtered for spcified taskID if mwnrionws)
function getbuilddefinitions5.1 ([string] $projectname,[string] $pat,[string] $taskid, [string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
 if ($taskid.Length -gt 0)
  { $url = "$baseurl/$projectname/_apis/build/definitions?api-version=5.1&taskIdFilter=$taskid" }
 else
  { $url = "$baseurl/$projectname/_apis/build/definitions?api-version=5.1" }

$builddefinitions = (Invoke-RestMethod ` -Uri "$url" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
return $builddefinitions
}
### GET Taskgroup List 
function gettaskgrouplist ([string] $projectname,[string] $pat,[string] $baseurl="https://spglobal.visualstudio.com", [string] $taskId)
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
if ($taskid.Length -gt 0)
{$uri = "$baseurl/$projectname/_apis/distributedtask/taskgroups?api-version=6.0-preview.1" }
else
{$uri = "$baseurl/$projectname/_apis/distributedtask/taskgroups?taskIdFilter=$taskID&api-version=6.0-preview.1"}
$tglist = (Invoke-RestMethod ` -Uri "$uri" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=6.0-preview.1" } ` -Method Get ` -ContentType "application/json" ).value  

return $tglist
}
### GET Repository List 
function getgitrepolist ([string] $projectname,[string] $pat,[string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$repolist = (Invoke-RestMethod ` -Uri "$baseurl/$projectname/_apis/git/repositories?api-version=4.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1" } ` -Method Get ` -ContentType "application/json" ).value  
return $repolist
}
### GET Specific Repository 
function getgitrepo ([string] $projectname,[string] $pat,[string] $repoID,[string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$repolist = (Invoke-RestMethod ` -Uri "$baseurl/$projectname/_apis/git/repositories/$repoID?api-version=4.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1" } ` -Method Get ` -ContentType "application/json" ).value  
return $repo
}