﻿
function getprojectidapi5.1 ([string] $projectname,[string] $pat,[string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$projectlist = (Invoke-RestMethod ` -Uri "$baseurl/_apis/projects?api-version=5.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
$projectid = $projectlist | select id,name | where name -eq $projectname
return $projectid.id
}

function getallbuilddefiitions5.1 ([string] $projectname,[string] $pat,[string] $baseurl="https://spglobal.visualstudio.com")
{
<#
$projectname = 'SNLServiceModules'
$projectid = '0d845a76-0046-4253-84c4-ccc77a3ea325'
$pat = ''
#>
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$buildlist = (Invoke-RestMethod ` -Uri "$baseurl/$projectname/_apis/build/definitions?api-version=5.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
return $buildlist
}

function gettaskspecificbuild ([string] $projectname,[string] $pat,[string] $taskid, [string] $baseurl="https://spglobal.visualstudio.com")
{
<#
$projectname = 'SNLServiceModules'
$projectid = '0d845a76-0046-4253-84c4-ccc77a3ea325'
$pat = ''
#>
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$buildlist = (Invoke-RestMethod ` -Uri "$baseurl/$projectname/_apis/build/definitions?api-version=5.1&taskIdFilter=$taskid" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
return $buildlist
}

clear
$projectname = 'SNLServiceModules'
$projectid = '0d845a76-0046-4253-84c4-ccc77a3ea325'
$pat = 'p2iwv5wnrj72kydprlnfgpvgvwrycwqhsvxrdfm5wu6m2priko4a'
$dynamicprojectid = getprojectidapi5.1 SNLServiceModules $pat


$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$filteredbuilds = (Invoke-RestMethod ` -Uri "https://spglobal.visualstudio.com/$projectname/_apis/build/definitions?api-version=5.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  


$projectname = 'SNLServiceModules'
$projectid = '0d845a76-0046-4253-84c4-ccc77a3ea325'
$pat = 'eq7vy5jbgvuqxgm4pmjlirqs2a3wvfv3vrej3df6volvu56j7a5a'
$dynamicfilterbuilds = getallbuilddefiitions5.1 'SNLServiceModules' $pat


$filteredbuildids = $filteredbuilds | select id 
$filteredbuildnames = $filteredbuilds | select name
$totalbuilds = $filteredbuildids.Count
#write-host 'total -' $totalbuilds

$validbuildcount = 0
$j = 0
[void][System.Reflection.Assembly]::LoadFile("$pwd\Newtonsoft.Json.dll") 
for($i = 0;$i-lt $totalbuilds;$i++)
{
$buildnumber = ($filteredbuildids.GetValue($i)).id
$buildname = ($filteredbuildnames.GetValue($i)).name
#if($buildnumber -eq 1346){
#write-host $buildnumber
#$defresponse = (Invoke-WebRequest ` -Uri "https://spglobal.visualstudio.com/$projectid/_apis/build/Definitions/$buildnumber" -ContentType "application/json" -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" }).Content
$defresponse = (Invoke-WebRequest ` -Uri "https://spglobal.visualstudio.com/$dynamicprojectid/_apis/build/Definitions/$buildnumber" -ContentType "application/json" -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" }).Content
$fullstring = $defresponse.tostring()
$startindex = $fullstring.IndexOf('deploy-test_svc')
if($startindex -lt 0)
{continue}
$buildDefinition = [Newtonsoft.Json.JsonConvert]::DeserializeObject($defresponse)
$buildDefinition.process.yamFilename
$variables = $buildDefinition.variables
#write-host "yaml file"
#write-host $buildDefinition.process.yamFilename
foreach ($var in $variables){
#write-host $var.path
$name = $var.Name
$SVCTest = $buildDefinition.variables[$name].value.ToString()
#write-host $var.path
if ($SVCTest -eq 'deploy-test_svc')
{
<#
write-host "Build: ID- $buildnumber, Name- $buildname "
write-host "BuildURL:https://spglobal.visualstudio.com/$projectname/_build?definitionId=$buildnumber&_a=summary"
write-host "Variable: $name"
write-host "---------------"
#>
write-host "$buildnumber,$buildname,https://spglobal.visualstudio.com/$projectname/_build?definitionId=$buildnumber&_a=summary,$name"
}
}
}
#}