﻿Function Do-Initalize-F5([String] $ip, [String] $partition,[String] $username, [String] $Pass){
Add-PSSnapIn -Name iControlSnapIn
if($username -eq "")
{
$username= Read-Host "Please enter your F5 username"
}
if($Pass -eq "")
{
$SecurePassword = Read-Host -assecurestring "Please enter your F5 password"
$BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePassword)
$Pass = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
}
$session=Initialize-F5.iControl -Hostname $ip -Username $username -password $Pass
 if($session)
{  
    $ic = Get-F5.icontrol
     write-host "Login Sucessful"
    if ($partition -ne "")
    {
    $ic.ManagementPartition.set_active_partition($Partition)
    write-host Partition is set as $partition

    }else
    {
    Write-host Partition is set as Default - $ic.ManagementPartition.get_active_partition()
    } 
    }else
    {
    write-host "Login unsucessful, Please check the hostname,username,password"
    }

}

function displayformattedstatus([String] $statustext, [String] $Member)
{
$formattedtext = ""
if ($statustext -eq "ENABLED_STATUS_DISABLED")
  {write-host -ForegroundColor Red "$Member is disabled" }

if ($statustext -eq "ENABLED_STATUS_ENABLED")
  {write-host -ForegroundColor Green "$Member is enabled" }

}
function selectfiles([String] $filepath)
{

     $initialDirectory = "D:\Dhwani"
     if( $filepath -ne ""){
     $initialDirectory = $filepath
     }

    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null
    $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $OpenFileDialog.initialDirectory = $initialDirectory
    #$OpenFileDialog.filter = "*.config"
    #$OpenFileDialog.Multiselect = $true
    $OpenFileDialog.ShowDialog()
    [String[]] $filelist =  $OpenFileDialog.FileName
    return $filelist

}