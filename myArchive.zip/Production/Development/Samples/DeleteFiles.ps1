﻿function getprojectidapi5.1 ([string] $projectname,[string] $pat,[string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$projectlist = (Invoke-RestMethod ` -Uri "$baseurl/_apis/projects?api-version=5.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
$projectid = $projectlist | select id,name | where name -eq $projectname
return $projectid.id
}

function getbuilddefinitions5.1 ([string] $projectname,[string] $pat,[string] $taskid, [string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
 if ($taskid.Length -gt 0)
  { $url = "$baseurl/$projectname/_apis/build/definitions?api-version=5.1&taskIdFilter=$taskid" }
 else
  { $url = "$baseurl/$projectname/_apis/build/definitions?api-version=5.1" }

$builddefinitions = (Invoke-RestMethod ` -Uri "$url" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
return $builddefinitions
}
clear
$pat = 'p2iwv5wnrj72kydprlnfgpvgvwrycwqhsvxrdfm5wu6m2priko4a'# 'jokosizlshbve6spahju7ryu3gemvqgj7xcjmbyvprkvjaarjasq' #'fxs3qabuylbip2i6s4664tvl5kaqk72unptt2qixx6nrcilhycya' #
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
###### SOURCE #####
$projectname = 'contentsystems' 
$projectid = getprojectidapi5.1 $projectname $pat 
#$filteredbuilds = (Invoke-RestMethod ` -Uri "https://spglobal.visualstudio.com/$projectname/_apis/build/definitions?api-version=5.1&taskIdFilter=71a9a2d3-a98a-4caa-96ab-affca411ecda" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
#$filteredbuildids = $filteredbuilds | select id 
$buildnumber = 2086
$defresponse = (Invoke-WebRequest ` -Uri "https://spglobal.visualstudio.com/$projectid/_apis/build/Definitions/$buildnumber" -ContentType "application/json" -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" }).Content
[void][System.Reflection.Assembly]::LoadFile("$pwd\Newtonsoft.Json.dll")
$buildDefinition = [Newtonsoft.Json.JsonConvert]::DeserializeObject($defresponse)
$version = [Newtonsoft.Json.JsonConvert]::SerializeObject("version")
$steps = $buildDefinition.process.phases.steps
$phases = $buildDefinition.process.phases

foreach($step in $steps)
{

}
$targetstep = $step
###### TARGET #######
$projectname = 'contentsystems' 
$projectid = getprojectidapi5.1 $projectname $pat 
$targetbuildnumber = 4990
$buildlist = getbuilddefinitions5.1 $projectname $pat 
foreach($build in $buildlist)
{
if($build.id -eq $targetbuildnumber)
{
$updated=$build.id
write-host "$updated is considered to update"
write-host "------------------https://spglobal.visualstudio.com/$projectname/_apis/build/definitions/$updated-----------------"
$defresponse_t = (Invoke-WebRequest ` -Uri "https://spglobal.visualstudio.com/$projectid/_apis/build/Definitions/$updated" -ContentType "application/json" -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" }).Content
$buildDefinition_t = [Newtonsoft.Json.JsonConvert]::DeserializeObject($defresponse_t)

$phases = $buildDefinition_t.process.phases
$cnt = 0
foreach($phase in $phases)
{
$cnt+=1
write-host "Counter = $cnt"
foreach($step_t in $phase.steps)
{

}
 if($step_t.task.id.tostring() -ne "b7e8b412-0437-4065-9371-edc5881de25b")
 {
   write-host "After Task Comparison"
   $phase.steps.Add($targetstep)
   $buildDefinitionUpdated = [Newtonsoft.Json.JsonConvert]::SerializeObject($buildDefinition_t)

   $postData = [System.Text.Encoding]::UTF8.GetBytes($buildDefinitionUpdated)
   # The TFS2015 REST endpoint requires an api-version header, otherwise it refuses to work properly.
   $headers = @{ "Authorization" = "Basic $auth";"Accept" = "api-version=5.1" }
   $response = Invoke-WebRequest -Uri https://spglobal.visualstudio.com/$projectname/_apis/build/definitions/$updated -Headers $headers `
              -Method Put -Body $postData -ContentType "application/json"
   $response.StatusDescription

}
}


}
else
{
$notupdated=$build.name
write-host "$notupdated is not updated"
}
}

