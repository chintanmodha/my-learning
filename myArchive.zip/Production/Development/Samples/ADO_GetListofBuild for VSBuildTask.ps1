﻿$projectname = 'CSD-Services'
$projectid = '73f78e08-e7e3-4fa3-a40c-6cf3c709a7da'

$pat = 'jokosizlshbve6spahju7ryu3gemvqgj7xcjmbyvprkvjaarjasq'
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$filteredbuilds = (Invoke-RestMethod ` -Uri "https://spglobal.visualstudio.com/$projectname/_apis/build/definitions?api-version=5.1&taskIdFilter=71a9a2d3-a98a-4caa-96ab-affca411ecda" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
$filteredbuildids = $filteredbuilds | select id 
$filteredbuildnames = $filteredbuilds | select name
$totalbuilds = $filteredbuildids.Count
write-host 'total -' $totalbuilds

$validbuildcount = 0
for($i = 0;$i-lt $totalbuilds;$i++)
{
$buildnumber = ($filteredbuildids.GetValue($i)).id
$buildname = ($filteredbuildnames.GetValue($i)).name

$defresponse = (Invoke-WebRequest ` -Uri "https://spglobal.visualstudio.com/$projectid/_apis/build/Definitions/$buildnumber" -ContentType "application/json" -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" }).Content

$fullstring = $defresponse

$startindex = $fullstring.IndexOf('"task":{"id":"71a9a2d3-a98a-4caa-96ab-affca411ecda"')
$endindex = $fullstring.IndexOf('"logFileVerbosity"',$startindex)

#write-host "Start Index: $startindex"
if($startindex -lt 0)
{ write-host 'For BuildID: '$buildnumber ', StartIndex is less than 0'
  continue}
if($endindex -lt 0)
{ write-host 'For BuildID: '$buildnumber ', logFileVerbosity not found'
continue}
#write-host "End Index: $endindex,    BuildID: $buildnumber"

$enablestartindex = $fullstring.LastIndexOf('"enabled":',$startindex)
$enableendindex = $fullstring.IndexOf(',',$enablestartindex)
$enablelength = $enableendindex - $enablestartindex
$enablecheckstring = $fullstring.Substring($enablestartindex,$enablelength)
#write-host $enablecheckstring.Substring($enablecheckstring.IndexOf(':')+1)

if($enablecheckstring.Substring($enablecheckstring.IndexOf(':')+1) -eq 'true') 
{
$validbuildcount = $validbuildcount+1
write-host 'https://spglobal.visualstudio.com/$projectid/_apis/build/Definitions/'$buildnumber ---  $buildname

}
}



write-host "Total Build Count: $totalbuilds"
write-host "ValidBuild Count: $validbuildcount"