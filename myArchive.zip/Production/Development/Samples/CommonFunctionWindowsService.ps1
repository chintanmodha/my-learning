#Stop One\Multiple Service(s) on same Server
function stopMultiServices([String]$ServerName,[String]$ServiceName)
{
$service = $ServiceName.Split(";")
for($i=0;$i-lt$service.Count;$i++){

$status = (get-service -ComputerName $ServerName -Name $service[$i]).status
Write-Host $service[$i] " on $ServerName is $status"

if ($status -eq "Running") {
(get-service -ComputerName $ServerName -Name $service[$i]).Stop()
}
do
{
$status = (get-service -ComputerName $ServerName -Name $service[$i]).status
}while ($status -ne "Stopped" )
Write-Host "---------------------"
Write-Host $service[$i] " on $ServerName is $status"
}Start-Sleep -s 5
}

#Start One\Multiple Service(s) on same Server
function startMultiServices([String]$ServerName,[String]$ServiceName)
{
$service = $ServiceName.Split(";")
for($i=0;$i-lt$service.Count;$i++){

$status = (get-service -ComputerName $ServerName -Name $service[$i]).status
Write-Host $service[$i] " on $ServerName is $status"

if ($status -eq "Stopped") {
(get-service -ComputerName $ServerName -Name $service[$i]).Start()
}
do
{
$status = (get-service -ComputerName $ServerName -Name $service[$i]).status
}while ($status -ne "Running" )
Write-Host "---------------------"
Write-Host $service[$i] " on $ServerName is $status"
}
Start-Sleep -s 5
}