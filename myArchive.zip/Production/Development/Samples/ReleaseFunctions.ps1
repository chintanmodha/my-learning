﻿# To get live server name 
function liveServer([String] $servercommonname)
{
try {
return (Resolve-DnsName $servercommonname -ErrorAction Stop).NameHost.Split(".")[0]
}
catch {
return $servercommonname
}
} 
# To get list of locked file on AppServers (IndDoc, PakDoc, SNLDocMnl etc) for WR, AR related files
function Show-LockedFiles([String]$location,[String]$path){


$ips = [System.Net.Dns]::Resolve($location).HostName

psfile \\$ips  $path

}

# To close locked file on AppServers (IndDoc, PakDoc, SNLDocMnl etc) for WR, AR related files
function Close-LockedFiles{
param(
[Parameter(mandatory=$true)][String]$location,
[Parameter(mandatory=$true)][String]$path
)

$ips = [System.Net.Dns]::Resolve($location).HostName

psfile \\$ips  $path -c

}

# To Copy Files from Source to Destination 
function DeployFilesAll([String]$source,[String]$destination)
{

$days = -15
$filepath = $source
If (!(Test-Path $destination)) {
 
   New-Item -Path $destination -ItemType Directory
   }

Copy-Item -Path $filepath -Destination $destination -Force  -ErrorAction Inquire

$newfilecount =  (Get-ChildItem -Path $destination  -Filter *.* | ? { $_.LastWriteTime -gt (Get-Date).AddDays($days)}).Count
return $newfilecount
}

# To Copy Files from Source to Destination 
function GetLatestFileCount([String]$path,[int]$days,[String]$date)
{

$filepath = $path
if ($days -ge 1)
{
$days = $days * -1
$newfilecount =  (Get-ChildItem -Path $filepath  -Filter *.* | ? { $_.LastWriteTime -gt (Get-Date).AddDays($days)}).Count
}
else
{
$filedate = [datetime]$date
$newfilecount =  (Get-ChildItem -Path $filepath  -Filter *.* | ? { $_.LastWriteTime -gt $filedate }).Count
}
return $newfilecount
}

# To Copy Files from Source to Destination  (With filters and number of days)
function DeployFilesFiltered([String]$source,[String]$destination,[String[]] $filters = "*.*" ,[int] $days)
{
$days = $days * -1
$filepath = $source
If (!(Test-Path $destination)) {
 
   New-Item -Path $destination -ItemType Directory
   }
foreach($filter in $filters)
{

Copy-Item -Path $filepath -Force -filter $filter -Destination $destination -ErrorAction Inquire

}
$newfilecount =  (Get-ChildItem -Path $destination  -Filter *.* | ? { $_.LastWriteTime -gt (Get-Date).AddDays($days)}).Count
return $newfilecount
}

# To Copy Files from Source to Destination  (With filters and number of days)
function DeployFilesFiltered_v2([String]$source,[String]$destination,[String[]] $filters = "*.*" ,[int] $days=12)
{
$days = $days * -1
$filepath = $source + "\*.*"
If (!(Test-Path $destination)) {
 
   New-Item -Path $destination -ItemType Directory
   }
foreach($filter in $filters)
{

Copy-Item -Path $filepath -Force -filter $filter -Destination $destination -ErrorAction Inquire

}
$newfilecount =  (Get-ChildItem -Path $destination  -Filter *.* | ? { $_.LastWriteTime -gt (Get-Date).AddDays($days)}).Count
return $newfilecount
}


# To Backup Files from Source  (With filters and optional backuppath)
function BackupFiles([String]$destination,[String[]] $filters = "*.*")
{
$filepath = $destination + "\*.*"

$backupfoldername = Get-Date -Format "MMddyyyy"

$destination = $destination + "\Backup\" +$backupfoldername

If (!(Test-Path $destination)) {
 
   New-Item -Path $destination -ItemType Directory
   }
foreach($filter in $filters) #$filters should be passed as @("value1","value2")
{

Copy-Item -Path $filepath -Force -filter $filter -Destination $destination -ErrorAction Inquire

}
$newfilecount =  (Get-ChildItem -Path $destination).Count
return $newfilecount
}
############################################## Other Useful Functionalities #####################################
# To Manage NLB Cluster
# Check Status of NLB Cluster
function CheckNLB([String]$ServerName)
{
Get-nlbclusternode -hostname $ServerName
}
# Pull Out of NLB Cluster
function StopNLB([String]$ServerName,[String]$TimeOut = 600)
{
Stop-NLBClusterNode -HostName $ServerName -Drain -TimeOut $TimeOut
}
# Push Back in NLB Cluster
function StartNLB([String]$ServerName)
{
Start-NLBClusterNode -HostName $ServerName
}

#Windows Service Management
#Check Status of Windows Service
function checkService([String]$ServerName,[String]$ServiceName)
{
$status = (get-service -ComputerName $ServerName -Name $ServiceName).Status
Write-Host "$ServiceName on $ServerName is $status"
}

#Start a Windows Service
function startService([String]$ServerName,[String]$ServiceName)
{
$status = (get-service -ComputerName $ServerName -Name $ServiceName).status
Write-Host "$ServiceName on $ServerName is $status"

if ($status -eq "Stopped") {
(get-service -ComputerName $ServerName -Name $ServiceName).Start()
}
do
{
$status = (get-service -ComputerName $ServerName -Name $ServiceName).status
}while ($status -ne "Running" )
Write-Host "---------------------"
Start-Sleep -s 3
Write-Host "$ServiceName on $ServerName is $status"
}

#Stop a Windows Service
function stopService([String]$ServerName,[String]$ServiceName)
{
$status = (get-service -ComputerName $ServerName -Name $ServiceName).status
Write-Host "$ServiceName on $ServerName is $status"

if ($status -eq "Running") {
(get-service -ComputerName $ServerName -Name $ServiceName).Stop()
}
do
{
$status = (get-service -ComputerName $ServerName -Name $ServiceName).status
}while ($status -ne "Stopped" )
Write-Host "---------------------"
Start-Sleep -s 3
Write-Host "$ServiceName on $ServerName is $status"

}

# Web Application Pool Management
#To Start Application Pool

    Function startAppPool ( [String]$ServerName,[string]$appPoolName)
    {

	 [System.Reflection.Assembly]::LoadWithPartialName(“Microsoft.Web.Administration”)
        $objServer = [Microsoft.Web.Administration.ServerManager]::OpenRemote($ServerName)
        $status = $objServer.ApplicationPools[$appPoolName].State
       
       if($status -ne 'Started')

       {
        $objServer.ApplicationPools[$appPoolName].Start()     

       }

       do
       {
       $status = $objServer.ApplicationPools[$appPoolName].State
       }while ($status -ne 'Started')
       Write-Host "---------------------"
Write-Host "$appPoolName on $ServerName is $status"

    }
    

#To Stop Application Pool

    Function stopAppPool( [String]$ServerName,[string]$appPoolName)
    {

	  [System.Reflection.Assembly]::LoadWithPartialName(“Microsoft.Web.Administration”)
        $objServer = [Microsoft.Web.Administration.ServerManager]::OpenRemote($ServerName)
        $status = $objServer.ApplicationPools[$appPoolName].State
       
       if($status -ne 'Stopped')

       {
        $objServer.ApplicationPools[$appPoolName].Stop()     

       }
           do
       {
       $status = $objServer.ApplicationPools[$appPoolName].State
       }while ($status -ne 'Stopped')
              Write-Host "---------------------"
Write-Host "$appPoolName on $ServerName is $status"
    }


    #To Get Status of Application Pool

    Function QueryAppPool( [String]$ServerName,[string]$appPoolName)
    {

	  [System.Reflection.Assembly]::LoadWithPartialName(“Microsoft.Web.Administration”)
        $objServer = [Microsoft.Web.Administration.ServerManager]::OpenRemote($ServerName)
        $status = $objServer.ApplicationPools[$appPoolName].State

Write-Host "$appPoolName on $ServerName is $status"
    }

function Check-IsGroupMember{

Param($user,$grp)

$strFilter = "(&(objectClass=Group)(name=" + $grp +"))"

$objDomain = New-Object System.DirectoryServices.DirectoryEntry

$objSearcher = New-Object System.DirectoryServices.DirectorySearcher
$objSearcher.SearchRoot = $objDomain
$objSearcher.PageSize = 1000
$objSearcher.Filter = $strFilter
$objSearcher.SearchScope = "Subtree"

$colResults = $objSearcher.FindOne()

$objItem = $colResults.Properties
([string]$objItem.member).contains($user)

}

function memberof($user,$group){
 $member = (Get-ADGroupMember -Identity $group).name -contains "$user"
    if ($member) {"$user is member of the $group"} else {"$user is not the member of $group"}
}