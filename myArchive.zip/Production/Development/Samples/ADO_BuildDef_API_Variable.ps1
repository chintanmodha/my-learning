﻿$projectname = 'SNLServiceModules'
$projectid = '0d845a76-0046-4253-84c4-ccc77a3ea325'

$pat = 'jokosizlshbve6spahju7ryu3gemvqgj7xcjmbyvprkvjaarjasq'
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$filteredbuilds = (Invoke-RestMethod ` -Uri "https://spglobal.visualstudio.com/$projectname/_apis/build/definitions?api-version=5.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
$filteredbuildids = $filteredbuilds | select id 
$filteredbuildnames = $filteredbuilds | select name
$totalbuilds = $filteredbuildids.Count
write-host 'total -' $totalbuilds

$validbuildcount = 0
$j = 0
for($i = 0;$i-lt $totalbuilds;$i++)
{
$buildnumber = ($filteredbuildids.GetValue($i)).id
$buildname = ($filteredbuildnames.GetValue($i)).name


$defresponse = (Invoke-WebRequest ` -Uri "https://spglobal.visualstudio.com/$projectid/_apis/build/Definitions/$buildnumber" -ContentType "application/json" -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" }).Content
$fullstring = $defresponse.tostring()
$startindex = $fullstring.IndexOf('deploy-test_svc')


#write-host "Start Index: $startindex"
if($startindex -lt 0)
{continue}
if($j -lt 5){

[void][System.Reflection.Assembly]::LoadFile("$pwd\Newtonsoft.Json.dll") 
$buildDefinition = [Newtonsoft.Json.JsonConvert]::DeserializeObject($defresponse)
$variables = $buildDefinition.variables
write-host $variables
foreach($variable in $variables){
$variablename = $variable.Name

write-host $variablename "- $variablename"
write-host $buildName "-" $buildDefinition.Name

}

<#
foreach($variable in $variables){
if($variable.value -eq "deploy-test_svc")
{
write-host "BuildNumber" $buildnumber
write-host "variable value" $variable.value
}
}#>
$j = $j+1
}

}

