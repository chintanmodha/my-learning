﻿$appcmd = "C:\Windows\System32\inetsrv\appcmd.exe"
$sitename = "Default Web Site"
$appname = "OnboardingForm"
$apppoolname = "OnboardingForm"

$sitecheck = &$appcmd list sites /text:name $sitename
write-host $sitecheck
if("$sitecheck" -ne "")
{ write-host "Site found"
    if(&$appcmd list app $sitename/$appname -ne "")
    { Write-host "Application Found" }
    else
    { Write-host "Application Not Found"
        if(&$appcmd list apppool $apppoolname -ne "")
        {
        }
        else
        { Write-Host "AppPool Not Found" }
        }

    }
else
{ write-host "Site Not Found"
$sitebinding = Read-Host "Enter Site Binding"
$physicalpath = Read-Host "Enter Physical Path"
    if(-not (Test-Path $physicalpath))
    {
    write-host "Path not found"
    }
    else
    {
    WRITE-HOST "Site-$sitename, Bindings-$sitebinding, PhysicalPath-$physicalpath"
    # &$appcmd add site /name:$sitename /bindings:$sitebinding /physicalpath:$physicalpath
    }

}

$appcmd = "C:\Windows\System32\inetsrv\appcmd.exe"
write-host "----Site Details----"
&$appcmd list site "TestSiteCM"
write-host "----App Details----"
&$appcmd list apps /site.name:"TestSiteCM/"
write-host "----VDIR Details----"
&$appcmd list vdirs /app.name:"TestSiteCM/"
write-host "----AppPool Details----"
&$appcmd list apppool TestAppPoolCM




SiteName
AppName
   App = SiteName\AppName
     vdir

AppPool
  mgdVersion
  mgdMode