﻿function createsite([String] $sitename, [String] $bindings)
{
    if($sitename -eq "" -or $bindings -eq "" )
    {write-host "SiteName and Bindings are mandatory"}
    else
    {
    $appcmd = "C:\Windows\System32\inetsrv\appcmd.exe"
    write-host "All parameters are found - Creating Site"
    Write-Host "SiteName: $sitename"
    Write-Host "Site bindings: $bindings"

    &$appcmd add site /name:$sitename /bindings:$bindings /physicalpath:$physicalpath
    }
}


function createapp([String] $sitename,[String] $apppool,[String] $physicalpath, [String] $appname)
{
$appcmd = "C:\Windows\System32\inetsrv\appcmd.exe"
$sitecheck = &$appcmd list sites /text:name $sitename
    if("$sitecheck" -ne "")
     { write-host "Site found"}
    else
     {  write-host "$sitename - Site Not Found"
        write-host "Creating New Site"
        $sitebinding = Read-Host "Enter Site Binding"
        createsite $sitename $sitebinding
     }

 $application = &$appcmd list app $sitename/$appname
 write-host "application variable = $application"
    if("$application" -contains "$appname")
      { Write-host "Application Found, Select different name or site" 
      
      }
    else
      { Write-host "Application Not Found"
        Write-host "Creating New Application"
        if(-not (Test-Path $physicalpath))
            {
                New-Item -path $physicalpath\ -ItemType Directory
            }
        &$appcmd add app /site.name:$sitename /path:/$appname /physicalPath:$physicalpath
      }

$applicationpool = &$appcmd list apppool $apppool
    if("$applicationpool" -ne "")
      {
        Write-host "Application Pool Found, Adding Application"
        &$appcmd set app $sitename/$appname /applicationPool:$apppool
      }
    else
      { 
          Write-Host "AppPool Not Found" 
          Write-Host "Creating AppPool"
          $mgdVersion = Read-Host "Enter Managed Framework Version eg.(v2.0, v4.0 etc.)"
          $mgdMode = Read-Host "Enter Managed Mode - i=integrated, c=classic"
          createapppool $apppool $mgdVersion $mgdMode
          &$appcmd set app $sitename/$appname /applicationPool:$apppool
      }
        
}


function createapppool([String] $apppool, [String] $mgdVersion,[String] $mgdMode)
{
$appcmd = "C:\Windows\System32\inetsrv\appcmd.exe"
$managedmode = ""
$mgdMode = $mgdMode.ToLower()
    if($mgdVersion -eq "" -or $apppool -eq "" -or $mgdMode -eq "" )
    {write-host "AppPool Name, Managedversion and ManagedMode are mandatory"}
    else
    {
    switch($mgdMode){
    "i" {$managedmode = "Integrated"}
    "c" {$managedmode = "Classic"}
    }
    write-host "All parameters are found - Creating AppPool"

    Write-Host "AppPools Name: $apppool"
    Write-Host "Managed Version: $mgdVersion"
    write-host "Managed Mode: $mgdMode"

    &$appcmd add apppool /name:$apppool
    &$appcmd set apppool $apppool /managedRuntimeVersion:$mgdVersion
    &$appcmd set apppool $apppool /managedPipelineMode:$managedmode

    }
}

createapp TestSiteCM TestAppPoolCM "D:\Apps\TestFolderCM" TestAppCM



