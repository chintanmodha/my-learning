﻿#List Subscriptions

$projectname = 'SNLServiceModules'
$projectid = '0d845a76-0046-4253-84c4-ccc77a3ea325'
$pat = 'jokosizlshbve6spahju7ryu3gemvqgj7xcjmbyvprkvjaarjasq'
$dynamicprojectid = getprojectidapi5.1 SNLServiceModules $pat
