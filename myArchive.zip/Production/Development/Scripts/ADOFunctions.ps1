function getprojectidapi5.1 ([string] $projectname,[string] $pat,[string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$projectlist = (Invoke-RestMethod ` -Uri "$baseurl/_apis/projects?api-version=5.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
$projectid = $projectlist | select id,name | where name -eq $projectname
return $projectid.id
}

function getbuilddefinitions5.1 ([string] $projectname,[string] $pat,[string] $taskid, [string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
 if ($taskid.Length -gt 0)
  { $url = "$baseurl/$projectname/_apis/build/definitions?api-version=5.1&taskIdFilter=$taskid" }
 else
  { $url = "$baseurl/$projectname/_apis/build/definitions?api-version=5.1" }

$builddefinitions = (Invoke-RestMethod ` -Uri "$url" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
return $builddefinitions
}

function getallbuilddefiitions5.1 ([string] $projectname,[string] $pat,[string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$buildlist = (Invoke-RestMethod ` -Uri "$baseurl/$projectname/_apis/build/definitions?api-version=5.1" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
return $buildlist
}

function getdefinitiondetail ([string] $projectid,[string] $pat, [string] $buildid,[string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$url = "$baseurl/$projectid/_apis/build/definitions/"+$buildid+"?api-version=5.1"
#write-host "url - $url"
$definition = (Invoke-WebRequest ` -Uri $url -ContentType "application/json" -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" }).Content
$buildDefinition = $definition | ConvertFrom-Json
return $buildDefinition
}

function gettaskspecificbuild ([string] $projectname,[string] $pat,[string] $taskid, [string] $baseurl="https://spglobal.visualstudio.com")
{
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$buildlist = (Invoke-RestMethod ` -Uri "$baseurl/$projectname/_apis/build/definitions?api-version=5.1&taskIdFilter=$taskid" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
return $buildlist
}

function getserviceconnectionbyname ([string] $pat,[string] $targetprojectname,[string] $serviceconnectionname)
    {
    $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
    $sc = (Invoke-RestMethod ` -Uri "https://dev.azure.com/spglobal/$targetprojectname/_apis/serviceendpoint/endpoints?endpointNames=$serviceconnectionname&api-version=6.0-preview.4" ` -Headers @{Authorization = "Basic $auth"; Accept = "application/json; api-version=4.1-preview.6" } ` -Method Get ` -ContentType "application/json" ).value  
    return $sc
    }

function increment_libraryvariable([string] $org,[string] $project,[string] $VariableGroupId,[string] $VariableName,[string] $pat)
{

Write-Host "NewValue : $NewValue"

$url = "https://dev.azure.com/$org/$project/_apis/distributedtask/variablegroups/$($VariableGroupId)?api-version=5.1-preview.1"

Write-Host "URL: $url"
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$authHeader = @{Authorization = "Basic $auth"}

$definition = Invoke-RestMethod -Uri $url -Headers $authHeader

Write-Host "Pipeline = $($definition | ConvertTo-Json -Depth 100)"

$currentvalue = $definition.variables.$VariableName.Value
$NewValue = [int]$currentvalue + 1

$definition.variables.$VariableName.Value = "$($NewValue)"

$definitionJson = $definition | ConvertTo-Json -Depth 100 -Compress

Invoke-RestMethod -Method Put -Uri $url -Headers $authHeader -ContentType "application/json" -Body ([System.Text.Encoding]::UTF8.GetBytes($definitionJson)) | Out-Null

}

function set_libraryvariable([string] $org,[string] $project,[string] $VariableGroupId,[string] $VariableName,[string] $NewValue,[string] $pat)
{

Write-Host "NewValue : $NewValue"

$url = "https://dev.azure.com/$org/$project/_apis/distributedtask/variablegroups/$($VariableGroupId)?api-version=5.1-preview.1"

Write-Host "URL: $url"
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$authHeader = @{Authorization = "Basic $auth"}

$definition = Invoke-RestMethod -Uri $url -Headers $authHeader

$definition.variables.$VariableName.Value = "$($NewValue)"

$definitionJson = $definition | ConvertTo-Json -Depth 100 -Compress

Invoke-RestMethod -Method Put -Uri $url -Headers $authHeader -ContentType "application/json" -Body ([System.Text.Encoding]::UTF8.GetBytes($definitionJson)) | Out-Null

}

function promote_package_azure ([string] $feed_name,[string] $package_name,[string] $package_version,[string] $viewname,[string] $pat)
{
    $feedName = "$feed_name"
    $packageName = "$package_name"
    $packageVersion = "$package_version"
    $viewName = "$viewname"

    $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
    $method = "PATCH"
 
    $restAPICallHeader = @{ Authorization = "Basic $auth" }
    
    $feedBaseURL = "https://feeds.dev.azure.com/spglobal/_apis/packaging/feeds"
    $packageBaseURL = "https://pkgs.dev.azure.com/spglobal/_apis/packaging/feeds"
    
    $feedIdURL = "$feedBaseURL/$feedName/?api-version=5.1-preview.1"
    $feedIdResponse = (Invoke-RestMethod -Method Get -Uri $feedIdUrl -Headers $restAPICallHeader -ContentType 'application/json')
    $feedId = $feedIdResponse.id
    
    $viewIdURL = "$feedBaseURL/$feedId/views/$viewName/?api-version=5.1-preview.1"
    $viewIdResponse = (Invoke-RestMethod -Method Get -Uri $viewIdUrl -Headers $restAPICallHeader -ContentType 'application/json')
    $viewId = $viewIdResponse.id
        
    $restAPICallBodyJson = @{
        views = @{
            op = 'add'
            path = '/views/-'
            value = "$viewId"
        }
    }
    $restAPICallBody = (ConvertTo-Json $restAPICallBodyJson)
          <#
    $packageQueryUrl = "$feedBaseURL/$feedId/packages?api-version=5.1-preview.1&packageNameQuery=$packageName"
    $packagesResponse = (Invoke-RestMethod -Method Get -Uri $packageQueryUrl -Headers $restAPICallHeader -ContentType 'application/json')
    $latestPackageVersion = ($packagesResponse.value.versions | ? { $_.isLatest -eq $True } | Select -ExpandProperty version)
    $encodedPackageVersion = [System.Web.HttpUtility]::UrlEncode($latestPackageVersion)
           #>
        Write-Host "Package Name: $packageName"
        Write-Host "Package Version: $latestPackageVersion"
        write-host "Package Passed Version- $packageVersion"

    $releaseViewURL = $packageBaseURL `
    + "/$($feedId)" `
    + "/nuget/packages/$packageName" `
    + "/versions/$packageVersion" `
    + "?api-version=5.1-preview.1"

    $response = Invoke-RestMethod -Method Patch -Uri $releaseViewURL -Headers $restAPICallHeader -ContentType 'application/json' -Body $restAPICallBody
    Write-Host $response
    }

function branchPolicy {          #([string] $projectname,[string] $pat,[string] $repoName, [int] $cpId, [int] $prId)
   [CmdletBinding(PositionalBinding=$true)] 
    param ( 
        [ValidateNotNull()]$organization = $(throw "organization is mandatory, please provide a value."), 
        [ValidateNotNull()]$project = $(throw "project is mandatory, please provide a value."),
        [ValidateNotNull()]$PAT = $(throw "PAT is mandatory, please provide a value."),
        [ValidateNotNull()]$repo = $(throw "repo name is mandatory, please provide a value."),
        [ValidateNotNull()]$branch = "#",
        [ValidateNotNull()]$minPRApproverCount = 2,
        [ValidateNotNull()]$mandatoryWITagging = "true"
      )
   #$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT"))
   #$organization = "spglobal"
   #$project = "DevOps Shared Framework"
   #$PAT = ""
   #$repo = "ReleaseServiceB-Ansible"
   #$branch = "#"
   $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT"))
   $header = @{ "Authorization" = "Basic $auth";"Accept" = "api-version=5.0" }
   $Url = "https://dev.azure.com/$organization/$project/_apis/git/repositories/$($repo)?api-version=4.1-preview.1"
   #write-host $cpUrl
   Try{
      $repository = Invoke-RestMethod -Uri $Url -Headers $header
      } Catch{
    Write-Error $_.Exception.Message
    }

    if($branch -ne "#")  
        { $branch = $repository.defaultBranch }
    else 
        { $branch = "refs/heads/$branch"  }

    $repoId = $repository.id
    if($minPRApproverCount -gt 0){
    $approverPolicy=@"
    {
	    "type": {
		    "id": "fa4e907d-c16b-4a4c-9dfa-4906e5d171dd"
	},
	    "revision": 1,
	    "isDeleted": false,
	    "isBlocking": true,
	    "isEnabled": true,
	    "settings": {
		    "allowDownvotes": false,
		    "blockLastPusherVote": false,
		    "creatorVoteCounts": false,
		    "requireVoteOnLastIteration": false,
		    "resetOnSourcePush": false,
		    "resetRejectionsOnSourcePush": false,
		    "minimumApproverCount": 2,
		    "scope": [{
			    "repositoryId": "$repoId",
			    "refName": "$branch",
			    "matchKind": "Exact"
		    }]
	    }
    }
"@

      $configurationUrl = "https://dev.azure.com/$organization/$project/_apis/policy/Configurations"
      $postData = [System.Text.Encoding]::UTF8.GetBytes($approverPolicy) 
      
      Try{
      $policyConfiguration = Invoke-RestMethod -Uri $configurationUrl -Headers $header -Method POST -Body $postData  -ContentType "application/json"
      write-host "Completing Cherry Pick Creation SUCCESSFULLY" -ForegroundColor Green
      return $policyConfiguration 
      }
      Catch
      {
      write-host "Some Error" -ForegroundColor Red
      write-error $_.Exception.Message 
      }
    }
if($mandatoryWITagging -eq "true"){
$workitemPolicy=@"
{
	"type": {
		"id": "40e92b44-2fe1-4dd6-b3d8-74a9c21d0c6e"
	},
	"revision": 1,
	"isDeleted": false,
	"isBlocking": true,
	"isEnabled": true,
	"settings": {
		"allowDownvotes": false,
		"blockLastPusherVote": false,
		"creatorVoteCounts": false,
		"requireVoteOnLastIteration": false,
		"resetOnSourcePush": false,
		"resetRejectionsOnSourcePush": false,
		"minimumApproverCount": 2,
		"scope": [{
			"repositoryId": "$repoId",
			"refName": "$branch",
			"matchKind": "Exact"
		}]
	}
}
"@


$postData = [System.Text.Encoding]::UTF8.GetBytes($workitemPolicy) 

    Try{
    $policyConfiguration = Invoke-RestMethod -Uri $configurationUrl -Headers $header -Method POST -Body $postData  -ContentType "application/json"
    write-host "Completing Cherry Pick Creation SUCCESSFULLY" -ForegroundColor Green
    return $policyConfiguration 
    }
    Catch
    {
    write-host "Some Error" -ForegroundColor Red
    write-error $_.Exception.Message 
    }
}
}

function tagBuildPipeline{
   [CmdletBinding(PositionalBinding=$true)] 
    param ( 
        [ValidateNotNull()]$organization = $(throw "organization is mandatory, please provide a value."), 
        [ValidateNotNull()]$project = $(throw "project is mandatory, please provide a value."),
        [ValidateNotNull()]$PAT = $(throw "PAT is mandatory, please provide a value."),
        [ValidateNotNull()]$buildId = $(throw "build number is mandatory, please provide a value."),     
        [ValidateNotNull()]$tag = $(throw "tag is mandatory, please provide a value.")
      )
       
  $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT"))
  $header = @{ "Authorization" = "Basic $auth";"Accept" = "api-version=5.0" }
  Write-host "Tag Build Run as $tag"
  $url = "https://dev.azure.com/$organization/$project/_apis/build/builds/$buildId/tags/$($tag)?api-version=5.0"
  write-host $url
  $buildresponse = Invoke-RestMethod -Uri $url -Headers $header -Method PUT
  #tagBuildPipeline spglobal csd-dataprocessing $(PAT) 1361775 Template-REPONAME-BRANCHNAMEWITHREFHEAD
  }
function get_specific_pullrequest_commits {    #([string] $projectname,[string] $pat,[string] $repoName,[int] $Id)
        [CmdletBinding(PositionalBinding=$true)] 
    param ( 
        [ValidateNotNull()]$organization = $(throw "organization is mandatory, please provide a value."), 
        [ValidateNotNull()]$project = $(throw "project is mandatory, please provide a value."),
        [ValidateNotNull()]$PAT = $(throw "PAT is mandatory, please provide a value."),
        [ValidateNotNull()]$repo = $(throw "repo name is mandatory, please provide a value."),       
        [ValidateNotNull()]$pullrequestId = $(throw "repo name is mandatory, please provide a value.")
      )
    
    $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT"))
    $header = @{ "Authorization" = "Basic $auth";"Accept" = "api-version=5.0" }
    #write-host $Id
    $prURL = "https://dev.azure.com/$organization/$project/_apis/git/repositories/$repo/pullrequests/$($pullrequestId)//commits"
    write-host $prURL
    Try{
    $commitList = Invoke-RestMethod -Uri $prURL  -Headers $header -ContentType "application/json"
    return $commitList
    }  Catch{
    Write-Error $_.Exception.Message
    return $null
    }
}

function branchPolicy_YBYO {          
#Mandatory PR and WorkItem Assignment
   [CmdletBinding(PositionalBinding=$true)] 
    param ( 
        [ValidateNotNull()]$organization = $(throw "organization is mandatory, please provide a value."), 
        [ValidateNotNull()]$project = $(throw "project is mandatory, please provide a value."),
        [ValidateNotNull()]$PAT = $(throw "PAT is mandatory, please provide a value."),
        [ValidateNotNull()]$repo = $(throw "repo name is mandatory, please provide a value."),
        $numberofApprover = 2,
        $branch = "#"
      )
   #$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT"))
   #$organization = "spglobal"
   #$project = "DevOps Shared Framework"
   #$PAT = ""
   #$repo = "ReleaseServiceB-Ansible"
   #$branch = "#"
   $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT"))
   $header = @{ "Authorization" = "Basic $auth";"Accept" = "api-version=5.0" }
   $Url = "https://dev.azure.com/$organization/$project/_apis/git/repositories/$($repo)?api-version=4.1-preview.1"
   #write-host $cpUrl
   write-host "Branch Parameter - $branch" -ForegroundColor Yellow
   Try{
      $repository = Invoke-RestMethod -Uri $Url -Headers $header
      } Catch{
    Write-Error $_.Exception.Message
    }

    if($branch -eq "#")  
        { $branch = $repository.defaultBranch }
    else 
        { $branch = "refs/heads/$branch"  }

    $repoId = $repository.id

$policyurl = "https://dev.azure.com/$organization/$project/_apis/policy/configurations?&policyType=fa4e907d-c16b-4a4c-9dfa-4906e5d171dd"
$policy = (Invoke-RestMethod -Uri $policyurl -Headers $header).value
$addApprovalPolicy = $policy | Where-Object -FilterScript {
if($_.settings.scope.refName -eq $branch -and $_.settings.scope.repositoryId -eq $repoId)
{
return $_
}

}
if($addApprovalPolicy -eq $null)
{

    $approverPolicy=@"
    {
	    "type": {
		    "id": "fa4e907d-c16b-4a4c-9dfa-4906e5d171dd"
	},
	    "revision": 1,
	    "isDeleted": false,
	    "isBlocking": true,
	    "isEnabled": true,
	    "settings": {
		    "allowDownvotes": false,
		    "blockLastPusherVote": false,
		    "creatorVoteCounts": false,
		    "requireVoteOnLastIteration": false,
		    "resetOnSourcePush": true,
		    "resetRejectionsOnSourcePush": true,
		    "minimumApproverCount": $numberofApprover,
		    "scope": [{
			    "repositoryId": "$repoId",
			    "refName": "$branch",
			    "matchKind": "Exact"
		    }]
	    }
    }
"@

$configurationUrl = "https://dev.azure.com/$organization/$project/_apis/policy/Configurations"
$postData = [System.Text.Encoding]::UTF8.GetBytes($approverPolicy) 

Try{
$policyConfiguration = Invoke-RestMethod -Uri $configurationUrl -Headers $header -Method POST -Body $postData  -ContentType "application/json"
write-host "Pull Request and Approver Policy Applied Successfully" -ForegroundColor Green
#return $policyConfiguration 
}
Catch
{
write-host "Some Error" -ForegroundColor Red
write-error $_.Exception.Message 
}
}
else
{
Write-Host "Approval Policy is Already Existing"
}

$policyurl = "https://dev.azure.com/$organization/$project/_apis/policy/configurations?&policyType=40e92b44-2fe1-4dd6-b3d8-74a9c21d0c6e"
$policy = (Invoke-RestMethod -Uri $policyurl -Headers $header).value
$addApprovalPolicy = $policy | Where-Object -FilterScript {
if($_.settings.scope.refName -eq $branch -and $_.settings.scope.repositoryId -eq $repoId)
{
return $_
}

}
if($addApprovalPolicy -eq $null)
{

$workitemPolicy=@"
{
	"type": {
		"id": "40e92b44-2fe1-4dd6-b3d8-74a9c21d0c6e"
	},
	"revision": 1,
	"isDeleted": false,
	"isBlocking": true,
	"isEnabled": true,
	"settings": {
		"allowDownvotes": false,
		"scope": [{
			"repositoryId": "$repoId",
			"refName": "$branch",
			"matchKind": "Exact"
		}]
	}
}
"@


$postData = [System.Text.Encoding]::UTF8.GetBytes($workitemPolicy) 

Try{
$policyConfiguration = Invoke-RestMethod -Uri $configurationUrl -Headers $header -Method POST -Body $postData  -ContentType "application/json"
write-host "WorkItem Policy Applied Successfully" -ForegroundColor Green
#return $policyConfiguration 
}
Catch
{
write-host "Some Error" -ForegroundColor Red
write-error $_.Exception.Message 

}
}
else
{
Write-Host "WokrItem Policy is Already Existing"
}
}

function createReleaseItem {
    [CmdletBinding(PositionalBinding=$true)] 
    param ( 
        [ValidateNotNull()]$organization = $(throw "organization is mandatory, please provide a value."), 
        [ValidateNotNull()]$project = $(throw "project is mandatory, please provide a value."), 
        [ValidateNotNull()]$PAT = $(throw "PAT is mandatory, please provide a value."),
        [ValidateNotNull()]$workItemType = $(throw "workItemType is mandatory, please provide a value.")
    )

$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT"))
$header = @{ "Authorization" = "Basic $auth";"Accept" = "api-version=6.0" }
$releaseworkitemURL = "https://$organization.visualstudio.com/$project/_apis/wit/workitems/$"+"$workitemtype"+"?api-version=6.0"
$body="[
  {
    `"op`": `"add`",
    `"path`": `"/fields/System.Title`",
    `"value`": `"$($title)`"
  },
  {
    `"op`": `"add`",
    `"path`": `"/fields/Release.ActiveDate`",
    `"value`": `"$($activedate)`"
  },
    {
    `"op`": `"add`",
    `"path`": `"/fields/Release.TestedDate`",
    `"value`": `"$($DevTestingCodeMergeDate)`"
  },
    {
    `"op`": `"add`",
    `"path`": `"/fields/snl.DDate`",
    `"value`": `"$($DeploymentDate)`"
  },
      {
    `"op`": `"add`",
    `"path`": `"/fields/Microsoft.VSTS.Common.DescriptionHtml`",
    `"value`": `"$($description)`"
  },
        {
    `"op`": `"add`",
    `"path`": `"/fields/system.assignedto`",
    `"value`": `"Johnson, Jason <Jason.Johnson@spglobal.com>`"
  }

]"
write-host "Creating Workitem - $workItemType :- $releaseworkitemURL"
try{
Invoke-RestMethod -Uri $releaseworkitemURL -Headers $header -Method POST -Body $body -ContentType "application/json-patch+json"
}
Catch{
write-host "Something Caught"
Write-Error $_.Exception.Message 
return $null
}
}


function updateReleaseItem {
    [CmdletBinding(PositionalBinding=$true)] 
    param ( 
        [ValidateNotNull()]$organization = $(throw "organization is mandatory, please provide a value."), 
        [ValidateNotNull()]$project = $(throw "project is mandatory, please provide a value."), 
        [ValidateNotNull()]$PAT = $(throw "PAT is mandatory, please provide a value."),
        [ValidateNotNull()]$workitemId = $(throw "workItemId is mandatory, please provide a value.")
    )
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT"))
$header = @{ "Authorization" = "Basic $auth";"Accept" = "api-version=6.0" }
$releaseworkitemURL = "https://$organization.visualstudio.com/$project/_apis/wit/workitems/$workitemId"+"?api-version=6.0"
$body="[
  {
    `"op`": `"replace`",
    `"path`": `"/fields/System.Title`",
    `"value`": `"$($title)`"
  },
  {
    `"op`": `"replace`",
    `"path`": `"/fields/Release.ActiveDate`",
    `"value`": `"$($activedate)`"
  },
    {
    `"op`": `"replace`",
    `"path`": `"/fields/Release.TestedDate`",
    `"value`": `"$($DevTestingCodeMergeDate)`"
  },
    {
    `"op`": `"replace`",
    `"path`": `"/fields/snl.DDate`",
    `"value`": `"$($DeploymentDate)`"
  },
      {
    `"op`": `"replace`",
    `"path`": `"/fields/Microsoft.VSTS.Common.DescriptionHtml`",
    `"value`": `"$($description)`"
  },
        {
    `"op`": `"replace`",
    `"path`": `"/fields/system.assignedto`",
    `"value`": `"Johnson, Jason <Jason.Johnson@spglobal.com>`"
  }

]"
write-host "Updating Workitem - $workitemId :- $releaseworkitemURL"
try{
Invoke-RestMethod -Uri $releaseworkitemURL -Headers $header -Method PATCH -Body $body -ContentType "application/json-patch+json"
}
Catch{
write-host "Something Caught"
Write-Error $_.Exception.Message 
return $null
}
}


function Get_ReleaseWorkItem {
    [CmdletBinding(PositionalBinding=$true)] 
    param ( 
        [ValidateNotNull()]$organization = $(throw "organization is mandatory, please provide a value."), 
        [ValidateNotNull()]$project = $(throw "project is mandatory, please provide a value."), 
        [ValidateNotNull()]$PAT = $(throw "PAT is mandatory, please provide a value."),
        [ValidateNotNull()]$title = $(throw "repo name is mandatory, please provide a value.")
    )

$baseURL = "https://almsearch.dev.azure.com/$organization/$project/_apis/search/workItemQueryResults"
write-host $baseURL
  $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT"))
  $header = @{ "Authorization" = "Basic $auth";"Accept" = "api-version=5.0-preview.1" }
$json=@"
{
	"searchText": "$title",
	"skipResults": 0,
	"takeResults": 25,
	"sortOptions": [],
	"summarizedHitCountsNeeded": true,
	"searchFilters": {
		"Projects": ["Products"],
		"Work Item Types": ["Release"],
        "States":["Created"]
     },
	"filters": [],
	"includeSuggestions": false
}
"@

#write-host $json
$postData = [System.Text.Encoding]::UTF8.GetBytes($json) 
Try{
$release = Invoke-RestMethod -Uri $baseURL -Headers $header -Method POST -Body $postData  -ContentType "application/json"
return $release.results

}
Catch{
write-host "Something Caught"
Write-Error $_.Exception.Message 
return $null
}

}



Function generateHTML{
    [CmdletBinding(PositionalBinding=$true)] 
    param ( 
        [ValidateNotNull()]$appName = $(throw "appConfiguration is mandatory, please provide a value."), 
        [ValidateNotNull()]$activeDate = $(throw "appConfiguration is mandatory, please provide a value."), 
        [ValidateNotNull()]$DevTestingCodeMergeDate = $(throw "appConfiguration is mandatory, please provide a value."), 
        [ValidateNotNull()]$DeploymentDate = $(throw "appConfiguration is mandatory, please provide a value.") ,
        [ValidateNotNull()]$noStage = $(throw "appConfiguration is mandatory, please provide a value.") ,
        [ValidateNotNull()]$mrrDuration = $(throw "most recent release weekduration is mandatory, please provide a value."),
        [ValidateNotNull()]$upcomingDuration = $(throw "upcoming release duration is mandatory, please provide a value.") ,
        [ValidateNotNull()]$templateId = 1
    )

[datetime]$StageDeploymentDate = $DevTestingCodeMergeDate.AddDays(3)
[datetime]$StageTestingDate = $StageDeploymentDate.AddDays(3)
 
$activeDay = $activeDate.ToLongDateString()
$DevTestingCodeMergeDay=$DevTestingCodeMergeDate.ToLongDateString()
$StageDeploymentDay=$StageDeploymentDate.ToLongDateString()
$StageTestingDay=$StageTestingDate.ToLongDateString()
$DeploymentDay=$DeploymentDate.ToLongDateString()
$nxtDeploymentDay = $DeploymentDate.AddDays(1).ToLongDateString()

$releaseDescription = ""
$releaseAssignment = "<B>Release Manager: <BR>Backup Release Manager: <BR></B>"
$spreadsheet ="<B>Spreadsheet:</B><BR><BR>"
$activeDateLine = "<B> $activeDay : </B>No new user stories/bugs may be added to/removed from the release after this date without approval.<BR>"
if($templateId -eq 1 -or $templateId -eq 2 -or $templateId -eq 5 -or $templateId -eq 7)
{ $releaseDescription = $releaseAssignment + $spreadsheet + $activeDateLine }
if($templateId -eq 4)
{ $releaseDescription = $spreadsheet + $activeDateLine }
if($templateId -eq 6)
{ $releaseDescription = $activeDateLine }
if($templateId -eq 3) #Schema Injection
{ $releaseDescription = "<B>For information purpose only. Don't tag any stories to this release<BR><BR>" 
  $releaseDescription +=  "$activeDay : </B>No new item/object/lookup changes added after this date will be included with the production schema injection.<BR>"
}
if($templateId -ne 3)
{
       if($noStage -eq 0)
       {
        $devTestDateLine = "<B> $DevTestingCodeMergeDay : </B> All stories/bugs must be coded and tested in development by close of US business on this date.<BR>"
        $codeMergeDateLine = "<B> $DevTestingCodeMergeDay : </B> All code must be checked in and merged by close of US business on this date. Release managers will send notification when it is time to merge code. Please instruct your developers NOT to merge code until release managers send their notification.<BR>"
        $stageDeployLine = "<B> $StageDeploymentDay : </B>  Staging deployment will happen on this date. Release managers will send notification when the staging environment is ready to test.<BR>"
        $stageTestDateLine = "<B> $StageTestingDay : </B> All stories/bugs must be coded and tested in development by close of US business on this date.<BR>"
        $releaseDescription += $devTestDateLine + $codeMergeDateLine + $stageDeployLine + $stageTestDateLine
       }
       else
       {
        $devTestDateLine = "<B> $StageTestingDay : </B> All stories/bugs must be coded and tested in development by close of US business on this date.<BR>"
        $codeMergeDateLine = "<B> $StageTestingDay : </B> All code must be checked in and merged by close of US business on this date. Release managers will send notification when it is time to merge code. Please instruct your developers NOT to merge code until release managers send their notification.<BR>"
        $releaseDescription += $devTestDateLine + $codeMergeDateLine
       }

if($templateId -eq 1 -or $templateId -eq 5) #No prefernce
     {
       $deploymentDateLine = "<B> $DeploymentDay : </B>Product will be deployed on this date. Time TBD.<BR>If any of these dates are in danger of being missed, please notify Release Services B (ReleaseServicesB@spglobal.com) with the details as soon as possible."
     }
if($templateId -eq 4) #CIQ Pro Platform
     {
       $deploymentDateLine = "<B> $DeploymentDay : </B>Product will be deployed on this date. Time 8:00 PM ET.<BR>If any of these dates are in danger of being missed, please notify Release Services A (ReleaseServicesA@spglobal.com) with the details as soon as possible."
     }
if($templateId -eq 2) #WestX, Middle Tier
    {
      $deploymentDateLine = "<B> $DeploymentDay : </B>Product will be deployed on this date. Time 2:30 PM ET.<BR>If any of these dates are in danger of being missed, please notify Release Services B (ReleaseServicesB@spglobal.com) with the details as soon as possible."
    }
if($templateId -eq 6) #Ratefilings.com
    {
      $deploymentDateLine = "<B> $DeploymentDay : </B>Product will be deployed on this date. Time 2:30 PM ET.<BR>If any of these dates are in danger of being missed, please notify Release Services C (ReleaseServicesC@spglobal.com) with the details as soon as possible."
    }
if($templateId -eq 7) #CIQ Content Collection
     {
       $deploymentDateLine = "<B> $DeploymentDay (ET)/ $nxtDeploymentDay (IST) :- </B>Product will be deployed on this date. Time between 5:00 AM - 5:30 AM IST.<BR>If any of these dates are in danger of being missed, please notify Release Services B (ReleaseServicesB@spglobal.com) with the details as soon as possible."
   }
$releaseDescription += $deploymentDateLine
}

else
{
    $autoTestingDate = $activeDate.AddDays(5)
    $stgTestingDate = $activeDate.AddDays(10)
    $queryFirstDate = $activeDate.AddDays(-1)
    $queryLastDate = $DeploymentDate.AddDays(-4)
    $autoTestingDay = $autoTestingDate.ToLongDateString()
    $stgTestingDay = $stgTestingDate.ToLongDateString()

    $autoTestLine = "<B>$autoTestingDay :</B> Data Architect scripts will be run on DMZSQLTest, AVSQLStg01A, AVSQLStg01B, & ASSOASQLSg between 9:00-10:00 AM ET on this date for initial automated testing.<BR>"
    $stgTestLine = "<B>$stgTestingDay :</B> Item/object/lookup changes will be injected into the staging environment between 9:00-10:00 AM ET on this date for PM testing and additional automated testing.<BR>"
    $deploymentDateLine = "<B> $DeploymentDay : </B>Product will be deployed on this date.  Initial servers will be updated between 8:00-9:00 PM ET and injections will continue throughout the day..<BR>If any of these dates are in danger of being missed, please notify Release Services A (ReleaseServicesA@spglobal.com) with the details as soon as possible."
    $releaseDescription = $releaseDescription + $autoTestLine + $stgTestLine + $deploymentDateLine
    $queryLine = "<BR><B>To verify if your specific changes will be included with the injection, run this query on SNLDB2. <BR> EXEC SNLDB2.InternalUseOnly.dbo.SchemaInjectionList 0, 'DMZSQL1','$queryFirstDate','$queryLastDate'</B><BR>"
    $releaseDescription = $releaseDescription + $queryLine
   
}

$nxtReleaseDate=$DeploymentDate.AddDays($upcomingDuration)
$nxtReleaseDay = $nxtReleaseDate.ToLongDateString()
$nextReleaseLine = "<BR><BR>Next release is scheduled on <B> $nxtReleaseDay. </B><BR>"
$releaseDescription = $releaseDescription + $nextReleaseLine
write-host $releaseDescription
return $releaseDescription
<# Example
[datetime]$aDate = "2021-09-17"
[datetime]$devDate = "2021-09-24"
[datetime]$dDate = "2021-10-06"

generateHTMLDescrition CTS $aDate $devDate $dDate 0 2 2 7

#>
}





