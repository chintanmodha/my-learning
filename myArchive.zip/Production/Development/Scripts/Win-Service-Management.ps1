function updateCredentials ([string] $computer,[string] $username,[string] $password,[int] $retry = 2)
{
   $services = Get-WmiObject win32_service -computer $computer| ? {$_.StartName -eq "$username"} 
   ForEach ($service in $services) {
    $serviceName = $service.Name
    
    #STOPPING SERVICE
    $status = (get-service -ComputerName $computer -Name $serviceName).status
    Write-Host "$serviceName on $computer is $status"
    
      if ($status -eq "Running") {
      (get-service -ComputerName $computer -Name $serviceName).Stop()
      }
      $i = 0
      do
      {
        $status = (get-service -ComputerName $computer -Name $serviceName).status
        if($i -gt $retry)
        {
        $status = "Stopped"
        }
    
        $i++
        write-host $status
      }while($status -ne "Stopped")
      Write-Host "$serviceName on $computer is $status"
      Write-Host "Updating Password"
    
      $service.change($null,$null,$null,$null,$null,$null,$null,$password,$null,$null,$null)
      Write-Host "Password Changed for $serviceName on $computer, Starting Service ..."
    #STARTING SERVICE
    $status = (get-service -ComputerName $computer -Name $serviceName).status
    Write-Host "$serviceName on $computer is $status"
    
      if ($status -eq "Stopped") {
      (get-service -ComputerName $computer -Name $serviceName).Start()
      }
      $j = 0
      do
      {
      $status = (get-service -ComputerName $computer -Name $serviceName).status
      if($j -gt $retry)
      {
      $status = "Running"
      }
      $j++
      write-host $status
      }while ($status -ne "Running" )
      Write-Host "---------------------"
      Write-Host "$serviceName on $computer is $status"



 }
 }
function updateCredentialsDummy ([string] $computer,[string] $username,[string] $password,[int] $retry = 2)
{
   $services = Get-WmiObject win32_service -computer $computer| ? {$_.StartName -eq "$username"} 
   ForEach ($service in $services) {
    $serviceName = $service.Name

    $status = (get-service -ComputerName $computer -Name $serviceName).status
    Write-Host "$serviceName on $computer is $status"
    
      if ($status -eq "Running") 
      {  write-host "STOPPING SERVICE - $serviceName" }
      
      Write-Host "$serviceName on $computer is $status"
      Write-Host "Updating Password"
    
      ######### $service.change($null,$null,$null,$null,$null,$null,$null,$password,$null,$null,$null)
      Write-Host "Password Changed for $serviceName on $computer, Starting Service ..."

    $status = (get-service -ComputerName $computer -Name $serviceName).status
    Write-Host "$serviceName on $computer is $status"
    
      if ($status -eq "Stopped") 
      { write-host "STARTING SERVICE - $serviceName" }
      
      Write-Host "$serviceName on $computer is $status"



 }
 }
