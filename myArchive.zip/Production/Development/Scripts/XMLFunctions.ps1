function updatexmlfile([string] $filename, [string] $xmlnode, [array[][]] $keyvaluepair)
{
<#
write-host $filename
write-host $xmlnode
write-host "------------Before Changes--------------"
get-content $filename
#>
[xml]$xmlfile = get-content $filename 
$f = "*/$xmlnode"
write-host "--"+$f
$keyvaluepair.Count
$nodes = $xmlfile.ChildNodes.selectNodes($f) 

foreach($node in $nodes)
{
for([int] $i=0;$i -lt $keyvaluepair.Count;$i++)
{

$proptofind = $keyvaluepair[$i][0]
$proptochange = $keyvaluepair[$i][2]
$valuetofind = $keyvaluepair[$i][1]
$valuetochange = $keyvaluepair[$i][3]

write-host "FindProp -- FindValue -- ChangeProp -- ChangeValue"
write-host "$proptofind -- $valuetofind -- $proptochange -- $valuetochange"

if($node.$proptofind -eq $valuetofind)
{
<#
write-host "in If"
write-host "FindProp -- FindValue -- ChangeProp -- ChangeValue"
write-host "$proptofind -- $valuetofind -- $proptochange -- $valuetochange"
#>
$node.$proptochange = [string]$valuetochange

}

}
}
$xmlfile.Save($filename)
<#
write-host "------------After Changes--------------"
get-content $filename
#>
}